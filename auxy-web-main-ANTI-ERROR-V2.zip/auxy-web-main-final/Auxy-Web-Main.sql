begin;

-- =====================================================================
--  AUXY WEB  |  Auxy Web Main database (vNext)
--  Supabase -> SQL Editor -> paste all -> Run.   Safe to run again.
--
--  Native username/password authentication, Telegram-style chat permissions, channels/groups, saved messages, devices, media series and system welcome chat.
--  Username is public; the password is stored and verified only by Supabase Auth.
--  This SQL is rerunnable and does not delete existing auth users or app data.
--  Existing functions defined by this file are reset safely with CASCADE so old
--  return types/parameter names cannot block the rebuild. Policies/triggers are recreated.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;
create extension if not exists pg_trgm  with schema extensions;


-- =====================================================================
-- 1) TABLES
-- =====================================================================

-- public profile (readable by every signed-in user)
create table if not exists public.profiles (
  id              uuid primary key references auth.users (id) on delete cascade,
  username        text,
  display_name    text,
  avatar_url      text,
  bio             text,
  role            text not null default 'user',
  is_banned       boolean not null default false,
  ban_reason      text,
  followers_count int not null default 0,
  following_count int not null default 0,
  posts_count     int not null default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- migrate from the first schema (profiles had email / full_name)
do $$
begin
  alter table public.profiles add column if not exists username text;
  alter table public.profiles add column if not exists display_name text;
  alter table public.profiles add column if not exists bio text;
  alter table public.profiles add column if not exists role text not null default 'user';
  alter table public.profiles add column if not exists is_banned boolean not null default false;
  alter table public.profiles add column if not exists ban_reason text;
  alter table public.profiles add column if not exists followers_count int not null default 0;
  alter table public.profiles add column if not exists following_count int not null default 0;
  alter table public.profiles add column if not exists posts_count int not null default 0;
  if exists (select 1 from information_schema.columns
             where table_schema='public' and table_name='profiles' and column_name='full_name') then
    execute 'update public.profiles set display_name = coalesce(display_name, full_name)';
  end if;
end $$;

alter table public.profiles add column if not exists website text;
alter table public.profiles add column if not exists location text;
alter table public.profiles add column if not exists language text default 'fa';
alter table public.profiles add column if not exists last_login_at timestamptz;
alter table public.profiles add column if not exists last_seen_at timestamptz;

-- private, own-row-only data
create table if not exists public.user_private (
  user_id             uuid primary key references auth.users (id) on delete cascade,
  email               text,
  recovery_email      text,
  onboarded           boolean not null default false,
  password_set        boolean not null default false,
  username_changed_at timestamptz,
  settings            jsonb not null default '{}'::jsonb,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

alter table public.user_private add column if not exists recovery_email text;

do $$
begin
  if exists (select 1 from information_schema.columns
             where table_schema='public' and table_name='profiles' and column_name='email') then
    execute 'insert into public.user_private (user_id, email)
             select id, email from public.profiles on conflict (user_id) do nothing';
    alter table public.profiles drop column email;
  end if;
  alter table public.profiles drop column if exists full_name;
end $$;

-- app password hashes: NO client access at all
create table if not exists public.user_secrets (
  user_id         uuid primary key references auth.users (id) on delete cascade,
  password_hash   text not null,
  failed_attempts int not null default 0,
  locked_until    timestamptz,
  updated_at      timestamptz not null default now()
);

create table if not exists public.reserved_usernames (
  username      text primary key,
  allowed_email text not null,
  role          text not null default 'user'
);

create table if not exists public.handles (
  handle       text primary key check (handle ~ '^[a-z0-9_]{3,24}$'),
  owner_type   text not null check (owner_type in ('user','group','channel')),
  owner_id     uuid not null,
  created_at   timestamptz not null default now()
);
create unique index if not exists handles_owner_key on public.handles(owner_type, owner_id);
create index if not exists handles_owner_id_idx on public.handles(owner_id);

-- movies (main page; only publishers / owner may write)
create table if not exists public.movies (
  id               uuid primary key default gen_random_uuid(),
  title            text not null check (char_length(title) between 1 and 200),
  description      text check (char_length(description) <= 4000),
  year             int check (year between 1888 and 2100),
  duration_minutes int check (duration_minutes between 0 and 2000),
  genres           text[] not null default '{}',
  maturity         text not null default 'all',
  poster_url       text,
  backdrop_url     text,
  video_url        text not null,
  video_kind       text not null default 'url' check (video_kind in ('file','url','hls')),
  featured         boolean not null default false,
  published        boolean not null default true,
  views            bigint not null default 0,
  likes_count      int not null default 0,
  created_by       uuid references auth.users (id) on delete set null,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

alter table public.movies add column if not exists original_title text;
alter table public.movies add column if not exists original_language text;
alter table public.movies add column if not exists country text;
alter table public.movies add column if not exists release_date date;
alter table public.movies add column if not exists director text;
alter table public.movies add column if not exists cast_names text[] not null default '{}';
alter table public.movies add column if not exists writers text[] not null default '{}';
alter table public.movies add column if not exists rating numeric(3,1);
alter table public.movies add column if not exists rating_count int not null default 0;
alter table public.movies add column if not exists imdb_id text;
alter table public.movies add column if not exists tmdb_id text;
alter table public.movies add column if not exists trailer_url text;
alter table public.movies add column if not exists subtitle_languages text[] not null default '{}';
alter table public.movies add column if not exists audio_languages text[] not null default '{}';
alter table public.movies add column if not exists quality text;
alter table public.movies add column if not exists tags text[] not null default '{}';
alter table public.movies add column if not exists content_type text not null default 'movie';
alter table public.movies add column if not exists slug text;
alter table public.movies drop constraint if exists movies_content_type_check;
alter table public.movies add constraint movies_content_type_check check(content_type in ('movie','drama'));
create unique index if not exists movies_slug_key on public.movies(lower(slug)) where slug is not null;
create index if not exists movies_content_type_idx on public.movies(content_type,published,created_at desc);

create table if not exists public.movie_likes (
  user_id    uuid not null references auth.users (id) on delete cascade,
  movie_id   uuid not null references public.movies (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, movie_id)
);

create table if not exists public.movie_comments (
  id         uuid primary key default gen_random_uuid(),
  movie_id   uuid not null references public.movies (id) on delete cascade,
  user_id    uuid not null references auth.users (id) on delete cascade,
  parent_id  uuid references public.movie_comments (id) on delete cascade,
  body       text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.my_list (
  user_id    uuid not null references auth.users (id) on delete cascade,
  movie_id   uuid not null references public.movies (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, movie_id)
);

create table if not exists public.watch_progress (
  user_id          uuid not null references auth.users (id) on delete cascade,
  movie_id         uuid not null references public.movies (id) on delete cascade,
  position_seconds int not null default 0,
  duration_seconds int not null default 0,
  updated_at       timestamptz not null default now(),
  primary key (user_id, movie_id)
);

-- ads shown before a movie starts
create table if not exists public.ads (
  id               uuid primary key default gen_random_uuid(),
  title            text not null check (char_length(title) between 1 and 120),
  kind             text not null default 'image' check (kind in ('image','video')),
  media_url        text not null,
  link_url         text,
  duration_seconds int not null default 5 check (duration_seconds between 3 and 60),
  skip_after_seconds int check (skip_after_seconds between 0 and 60),   -- video ads: skip button appears after N s (null = cannot skip)
  active           boolean not null default true,
  created_at       timestamptz not null default now()
);

alter table public.ads add column if not exists skip_after_seconds int check (skip_after_seconds between 0 and 60);

create table if not exists public.ad_views (
  id         bigint generated always as identity primary key,
  ad_id      uuid references public.ads (id) on delete cascade,
  user_id    uuid references auth.users (id) on delete cascade,
  movie_id   uuid references public.movies (id) on delete set null,
  completed  boolean not null default false,
  created_at timestamptz not null default now()
);

-- Compatibility migration for older Auxy databases that already had ad_views
-- before movie_id was introduced. CREATE TABLE IF NOT EXISTS does not add new
-- columns to an existing table, so this explicit migration is required.
alter table public.ad_views
  add column if not exists movie_id uuid references public.movies (id) on delete set null;

-- scroll feed (user posts)
create table if not exists public.posts (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users (id) on delete cascade,
  kind           text not null check (kind in ('video','image','text')),
  caption        text check (char_length(caption) <= 2200),
  media_url      text,
  poster_url     text,
  likes_count    int not null default 0,
  comments_count int not null default 0,
  views_count    bigint not null default 0,
  created_at     timestamptz not null default now(),
  check (kind = 'text' or media_url is not null)
);

create table if not exists public.post_likes (
  user_id uuid not null references auth.users (id) on delete cascade,
  post_id uuid not null references public.posts (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table if not exists public.post_saves (
  user_id uuid not null references auth.users (id) on delete cascade,
  post_id uuid not null references public.posts (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table if not exists public.post_comments (
  id          uuid primary key default gen_random_uuid(),
  post_id     uuid not null references public.posts (id) on delete cascade,
  user_id     uuid not null references auth.users (id) on delete cascade,
  parent_id   uuid references public.post_comments (id) on delete cascade,
  body        text not null check (char_length(body) between 1 and 1000),
  likes_count int not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists public.comment_likes (
  user_id    uuid not null references auth.users (id) on delete cascade,
  comment_id uuid not null references public.post_comments (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, comment_id)
);

create table if not exists public.follows (
  follower_id  uuid not null references auth.users (id) on delete cascade,
  following_id uuid not null references auth.users (id) on delete cascade,
  created_at   timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users (id) on delete cascade,
  actor_id   uuid references auth.users (id) on delete cascade,
  type       text not null,
  post_id    uuid references public.posts (id) on delete cascade,
  comment_id uuid,
  read       boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id          uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users (id) on delete cascade,
  target_type text not null check (target_type in ('post','post_comment','movie_comment','user','movie','message','group','channel','series','episode')),
  target_id   uuid not null,
  reason      text not null check (char_length(reason) <= 500),
  status      text not null default 'open' check (status in ('open','done','dismissed')),
  created_at  timestamptz not null default now()
);

alter table public.reports add column if not exists category text not null default 'other';
alter table public.reports add column if not exists details text;
alter table public.reports add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.reports add column if not exists handled_by uuid references auth.users(id) on delete set null;
alter table public.reports add column if not exists updated_at timestamptz not null default now();
create index if not exists reports_target_idx on public.reports(target_type,target_id,created_at desc);


-- chat
create table if not exists public.conversations (
  id              uuid primary key default gen_random_uuid(),
  kind            text not null check (kind in ('direct','group')),
  title           text check (char_length(title) <= 60),
  avatar_url      text,
  created_by      uuid references auth.users (id) on delete set null,
  direct_key      text unique,
  created_at      timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);


-- Channel support: keep existing conversations and extend them in-place.
do $$
declare c record;
begin
  for c in select conname from pg_constraint
           where conrelid='public.conversations'::regclass
             and contype='c'
             and pg_get_constraintdef(oid) ilike '%kind%' loop
    execute format('alter table public.conversations drop constraint if exists %I', c.conname);
  end loop;
end $$;
alter table public.conversations add column if not exists username text;
alter table public.conversations add column if not exists description text;
alter table public.conversations add column if not exists is_public boolean not null default true;
alter table public.conversations add column if not exists invite_token text;
alter table public.conversations add constraint conversations_kind_check
  check (kind in ('direct','group','channel','system'));
alter table public.conversations drop constraint if exists conversations_username_check;
alter table public.conversations add constraint conversations_username_check
  check (username is null or username ~ '^[a-z0-9_]{3,24}$');
create unique index if not exists conversations_username_key on public.conversations(lower(username)) where username is not null;
create unique index if not exists conversations_invite_token_key on public.conversations(invite_token) where invite_token is not null;

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  user_id         uuid not null references auth.users (id) on delete cascade,
  role            text not null default 'member' check (role in ('member','admin')),
  last_read_at    timestamptz not null default now(),
  muted           boolean not null default false,
  joined_at       timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  sender_id       uuid references auth.users (id) on delete cascade,
  body            text check (char_length(body) <= 4000),
  media_url       text,
  media_type      text not null default 'image' check (media_type in ('image','audio','video','file','none')),
  media_name      text,
  reply_to        uuid references public.messages (id) on delete set null,
  created_at      timestamptz not null default now(),
  edited_at       timestamptz,
  deleted_at      timestamptz,
  check (body is not null or media_url is not null)
);

-- Message/audio and conversation customisation migrations for older Auxy databases.
alter table public.conversations add column if not exists theme jsonb not null default '{}'::jsonb;
alter table public.conversations add column if not exists message_limit int not null default 4000;
alter table public.conversations drop constraint if exists conversations_message_limit_check;
alter table public.conversations add constraint conversations_message_limit_check check (message_limit between 100 and 4000);
alter table public.conversations add column if not exists system_key text;
alter table public.conversations add column if not exists is_archived boolean not null default false;
alter table public.conversations add column if not exists updated_at timestamptz not null default now();
alter table public.messages drop constraint if exists message_body_not_empty_check;
alter table public.messages add constraint message_body_not_empty_check check (body is not null or media_url is not null);
alter table public.messages add column if not exists media_type text not null default 'image';
alter table public.messages add column if not exists media_name text;
alter table public.messages alter column sender_id drop not null;
alter table public.messages drop constraint if exists messages_media_type_check;
alter table public.messages add constraint messages_media_type_check check (media_type in ('image','audio','video','file','none'));

-- Permissions are stored per membership. Owner is explicit; admin/member are scoped roles.
alter table public.conversation_members drop constraint if exists conversation_members_role_check;
alter table public.conversation_members add constraint conversation_members_role_check check (role in ('owner','admin','member'));
alter table public.conversation_members add column if not exists permissions jsonb not null default '{"send_messages":true,"delete_messages":false,"pin_messages":false,"invite_members":true,"manage_members":false,"manage_admins":false,"edit_info":false,"view_members":false,"manage_theme":false}'::jsonb;
alter table public.conversation_members add column if not exists status text not null default 'active' check (status in ('active','left','banned'));

-- New media structures: series -> seasons -> episodes.
create table if not exists public.series (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 200),
  description text check (char_length(description) <= 4000),
  year int check (year between 1888 and 2100),
  genres text[] not null default '{}',
  maturity text not null default 'all',
  poster_url text,
  backdrop_url text,
  featured boolean not null default false,
  published boolean not null default true,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.series add column if not exists original_title text;
alter table public.series add column if not exists country text;
alter table public.series add column if not exists release_date date;
alter table public.series add column if not exists director text;
alter table public.series add column if not exists cast_names text[] not null default '{}';
alter table public.series add column if not exists writers text[] not null default '{}';
alter table public.series add column if not exists rating numeric(3,1);
alter table public.series add column if not exists trailer_url text;
alter table public.series add column if not exists quality text;
alter table public.series add column if not exists tags text[] not null default '{}';

create table if not exists public.seasons (
  id uuid primary key default gen_random_uuid(),
  series_id uuid not null references public.series(id) on delete cascade,
  season_number int not null check (season_number > 0 and season_number <= 1000),
  title text,
  created_at timestamptz not null default now(),
  unique(series_id, season_number)
);
create table if not exists public.episodes (
  id uuid primary key default gen_random_uuid(),
  season_id uuid not null references public.seasons(id) on delete cascade,
  episode_number int not null check (episode_number > 0 and episode_number <= 10000),
  title text not null check (char_length(title) between 1 and 200),
  description text check (char_length(description) <= 4000),
  duration_minutes int check (duration_minutes between 0 and 2000),
  poster_url text,
  video_url text not null,
  video_kind text not null default 'url' check (video_kind in ('file','url','hls')),
  published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(season_id, episode_number)
);

create table if not exists public.site_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);

-- Saved messages and reactions.
create table if not exists public.episode_watch_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  episode_id uuid not null references public.episodes(id) on delete cascade,
  position_seconds int not null default 0,
  duration_seconds int not null default 0,
  updated_at timestamptz not null default now(),
  primary key(user_id,episode_id)
);
create index if not exists episode_watch_user_idx on public.episode_watch_progress(user_id,updated_at desc);

create table if not exists public.saved_messages (
  user_id uuid not null references auth.users(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, message_id)
);

-- Compatibility migration for older saved_messages tables.
-- CREATE TABLE IF NOT EXISTS does not change an already-existing table, so
-- older deployments may be missing message_id (or use one of the legacy names).
do $$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='saved_messages' and column_name='message_id'
  ) then
    if exists (select 1 from information_schema.columns where table_schema='public' and table_name='saved_messages' and column_name='saved_id') then
      execute 'alter table public.saved_messages rename column saved_id to message_id';
    elsif exists (select 1 from information_schema.columns where table_schema='public' and table_name='saved_messages' and column_name='msg_id') then
      execute 'alter table public.saved_messages rename column msg_id to message_id';
    elsif exists (select 1 from information_schema.columns where table_schema='public' and table_name='saved_messages' and column_name='message_uuid') then
      execute 'alter table public.saved_messages rename column message_uuid to message_id';
    elsif exists (select 1 from information_schema.columns where table_schema='public' and table_name='saved_messages' and column_name='message') then
      execute 'alter table public.saved_messages rename column message to message_id';
    else
      execute 'alter table public.saved_messages add column message_id uuid';
    end if;
  end if;

  -- Old rows can remain nullable during migration; newly-saved rows always get a message_id.
  if not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='saved_messages' and column_name='created_at'
  ) then
    execute 'alter table public.saved_messages add column created_at timestamptz not null default now()';
  end if;
end $$;

-- Ensure new saved-message lookups are fast and duplicate-safe even when the
-- pre-existing table uses a different primary key.
create unique index if not exists saved_messages_user_message_uidx
on public.saved_messages(user_id, message_id)
where message_id is not null;
create table if not exists public.message_reactions (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  reaction text not null check (char_length(reaction) between 1 and 32),
  created_at timestamptz not null default now(),
  primary key(message_id, user_id, reaction)
);

-- Application-level device sessions. Revoking a device immediately blocks Auxy access there.
create table if not exists public.user_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  device_key text not null,
  label text,
  user_agent text,
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  revoked_at timestamptz,
  unique(user_id, device_key)
);

-- =====================================================================
-- 2) CONSTRAINTS & INDEXES
-- =====================================================================
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add  constraint profiles_role_check
  check (role in ('user','moderator','publisher','owner'));
alter table public.profiles drop constraint if exists profiles_username_format;
alter table public.profiles add  constraint profiles_username_format
  check (username is null or username ~ '^[a-z0-9_]{3,24}$');

create unique index if not exists profiles_username_key on public.profiles (lower(username)) where username is not null;
create index if not exists profiles_username_trgm on public.profiles using gin (username extensions.gin_trgm_ops);
create index if not exists movies_created_idx      on public.movies (created_at desc);
create index if not exists movies_title_trgm       on public.movies using gin (title extensions.gin_trgm_ops);
create index if not exists posts_created_idx       on public.posts (created_at desc);
create index if not exists posts_user_idx          on public.posts (user_id, created_at desc);
create index if not exists post_comments_post_idx  on public.post_comments (post_id, created_at desc);
create index if not exists post_comments_parent_idx on public.post_comments (parent_id);
create index if not exists movie_comments_movie_idx on public.movie_comments (movie_id, created_at desc);
create index if not exists movie_comments_parent_idx on public.movie_comments (parent_id);
create index if not exists follows_following_idx   on public.follows (following_id);
create index if not exists notifications_user_idx  on public.notifications (user_id, created_at desc);
create index if not exists messages_conv_idx       on public.messages (conversation_id, created_at desc);
create index if not exists members_user_idx        on public.conversation_members (user_id);
create index if not exists reports_status_idx      on public.reports (status, created_at desc);
create index if not exists watch_progress_user_idx on public.watch_progress (user_id, updated_at desc);
create index if not exists saved_messages_user_idx on public.saved_messages (user_id, created_at desc);
create index if not exists reactions_message_idx on public.message_reactions (message_id, created_at desc);
create index if not exists user_devices_user_idx on public.user_devices (user_id, last_seen_at desc);
create index if not exists series_created_idx on public.series (created_at desc);
create index if not exists seasons_series_idx on public.seasons (series_id, season_number);
create index if not exists episodes_season_idx on public.episodes (season_id, episode_number);
create unique index if not exists conversations_system_key_idx on public.conversations(system_key) where system_key is not null;


-- =====================================================================
-- FUNCTION RESET FOR RE-RUNS (ANTI-42P13)
-- =====================================================================
-- PostgreSQL cannot change an existing function's input-parameter names or
-- return type with CREATE OR REPLACE. Older Auxy databases may therefore have
-- incompatible versions of these functions. We remove every existing overload
-- whose name is defined by this script. The DROP ... CASCADE also removes old
-- RLS policies/triggers that depend on those functions; this script recreates
-- them later. This is deliberately name-based, so even a future signature
-- change (argument types, names, or return type) will not stop the rebuild.
do $$
declare
  r record;
begin
  for r in
    select n.nspname, p.proname, pg_get_function_identity_arguments(p.oid) as args
      from pg_proc p
      join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname = any(array[
    'app_role',
    'is_owner',
    'is_publisher',
    'is_staff',
    'is_banned',
    'is_conv_member',
    'set_updated_at',
    'handle_new_user',
    'trg_posts_count',
    'trg_post_likes',
    'trg_post_comments',
    'trg_comment_likes',
    'trg_follows',
    'trg_movie_likes',
    'trg_notify_follow',
    'trg_notify_like',
    'trg_notify_comment',
    'trg_message_bump',
    '_username_format_error',
    '_username_reserved',
    'check_username',
    'resolve_username_login',
    'provision_user_after_signup',
    'resolve_recovery_target',
    'admin_user_detail',
    'admin_report_detail',
    'admin_revoke_user_devices',
    'admin_set_site_setting',
    'claim_username',
    'sync_auth_password',
    'bootstrap_me',
    'ensure_profile',
    'finish_onboarding',
    'update_profile',
    'change_username_native',
    'delete_my_account_native',
    'set_app_password',
    'verify_app_password',
    'change_app_password',
    'change_username',
    'update_recovery_email',
    'increment_movie_view',
    'increment_post_view',
    'toggle_post_like',
    'toggle_movie_like',
    'toggle_comment_like',
    'touch_seen',
    'record_login',
    'login_postprocess',
    'start_direct_chat',
    'create_group',
    'create_channel',
    'search_channels',
    'join_channel',
    'join_channel_invite',
    'set_conversation_handle',
    'add_group_members',
    'leave_conversation',
    'mark_read',
    'my_conversations',
    'is_conv_manager',
    'conv_can_send_message',
    'conv_can_manage_members',
    'conv_can_manage_admins',
    'conv_can_view_members',
    'get_conversation_members',
    'set_member_role',
    'set_member_permissions',
    'add_channel_admin',
    'create_group_v2',
    'join_group_public',
    'join_group_invite',
    'resolve_public_handle',
    'set_conversation_theme',
    'save_message',
    'unsave_message',
    'list_saved_messages',
    'toggle_message_reaction',
    'ensure_auxy_welcome',
    'register_device',
    'list_my_devices',
    'revoke_device',
    'is_current_device_revoked',
    'create_series',
    'create_season',
    'create_episode',
    'admin_stats',
    'admin_list_users',
    'admin_set_role',
    'admin_set_ban',
    'admin_reset_password',
    'admin_delete_user',
    'submit_report',
    'conv_can_invite_members',
    'conv_can_manage_theme',
    'conv_can_edit_info',
    'conv_can_pin_messages'
       ])
  loop
    execute format('drop function if exists %I.%I(%s) cascade', r.nspname, r.proname, r.args);
  end loop;
end $$;

-- =====================================================================
-- 4) HELPER FUNCTIONS (used by policies)
-- =====================================================================
create or replace function public.app_role() returns text
language sql stable security definer set search_path = '' as $$
  select coalesce((select role from public.profiles where id = (select auth.uid())), 'user')
$$;

create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.app_role() = 'owner'
      or lower(coalesce((select username from public.profiles where id = (select auth.uid())), '')) = any(array['ali','support','auxy'])
$$;

create or replace function public.is_publisher() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.app_role() in ('publisher','owner')
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.app_role() in ('moderator','owner')
$$;

create or replace function public.is_banned() returns boolean
language sql stable security definer set search_path = '' as $$
  select coalesce((select is_banned from public.profiles where id = (select auth.uid())), false)
$$;

create or replace function public.is_conv_member(p_conv uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversation_members
                 where conversation_id = p_conv and user_id = (select auth.uid()) and status='active')
$$;


-- =====================================================================
-- 5) TRIGGERS
-- =====================================================================
create or replace function public.set_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
drop trigger if exists user_private_set_updated_at on public.user_private;
create trigger user_private_set_updated_at before update on public.user_private
  for each row execute function public.set_updated_at();
drop trigger if exists movies_set_updated_at on public.movies;
create trigger movies_set_updated_at before update on public.movies
  for each row execute function public.set_updated_at();

-- new native email/password user -> profile + private row + optional username
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  u text := lower(regexp_replace(trim(coalesce(new.raw_user_meta_data ->> 'username','')), '^@+', ''));
  nm text := nullif(btrim(coalesce(new.raw_user_meta_data ->> 'display_name', new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', '')), '');
  av text := nullif(btrim(coalesce(new.raw_user_meta_data ->> 'avatar_url', new.raw_user_meta_data ->> 'picture', '')), '');
begin
  if u <> '' then
    if public._username_format_error(u) is not null or public._username_reserved(u) then
      raise exception 'invalid_username';
    end if;
    if exists (select 1 from public.handles where handle = u)
       or exists (select 1 from public.profiles where lower(username) = u) then
      raise exception 'username_taken';
    end if;
  end if;

  insert into public.profiles (id, username, display_name, avatar_url, role)
  values (new.id, nullif(u,''), nm, av, case when u = any(array['ali','support','auxy']) then 'owner' else 'user' end)
  on conflict (id) do update set
    username     = coalesce(public.profiles.username, excluded.username),
    display_name = coalesce(public.profiles.display_name, excluded.display_name),
    avatar_url   = coalesce(public.profiles.avatar_url, excluded.avatar_url),
    role         = case when lower(coalesce(public.profiles.username, excluded.username,'')) = any(array['ali','support','auxy']) then 'owner' else public.profiles.role end;

  if u <> '' then
    insert into public.handles(handle, owner_type, owner_id) values (u, 'user', new.id);
  end if;

  insert into public.user_private (user_id, email, recovery_email, password_set, onboarded)
  values (new.id, new.email, nullif(lower(coalesce(new.raw_user_meta_data ->> 'recovery_email','')),''), nullif(coalesce(new.encrypted_password,''),'') is not null, nullif(u,'') is not null)
  on conflict (user_id) do update set
    email          = coalesce(excluded.email, public.user_private.email),
    recovery_email = coalesce(excluded.recovery_email, public.user_private.recovery_email),
    password_set   = public.user_private.password_set or excluded.password_set,
    onboarded      = public.user_private.onboarded or excluded.onboarded;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();


-- counters
create or replace function public.trg_posts_count() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then update public.profiles set posts_count = posts_count + 1 where id = new.user_id;
  else update public.profiles set posts_count = greatest(posts_count - 1, 0) where id = old.user_id; end if;
  return null;
end $$;
drop trigger if exists posts_count_trg on public.posts;
create trigger posts_count_trg after insert or delete on public.posts
  for each row execute function public.trg_posts_count();

create or replace function public.trg_post_likes() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then update public.posts set likes_count = likes_count + 1 where id = new.post_id;
  else update public.posts set likes_count = greatest(likes_count - 1, 0) where id = old.post_id; end if;
  return null;
end $$;
drop trigger if exists post_likes_trg on public.post_likes;
create trigger post_likes_trg after insert or delete on public.post_likes
  for each row execute function public.trg_post_likes();

create or replace function public.trg_post_comments() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then update public.posts set comments_count = comments_count + 1 where id = new.post_id;
  else update public.posts set comments_count = greatest(comments_count - 1, 0) where id = old.post_id; end if;
  return null;
end $$;
drop trigger if exists post_comments_trg on public.post_comments;
create trigger post_comments_trg after insert or delete on public.post_comments
  for each row execute function public.trg_post_comments();

create or replace function public.trg_comment_likes() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then update public.post_comments set likes_count = likes_count + 1 where id = new.comment_id;
  else update public.post_comments set likes_count = greatest(likes_count - 1, 0) where id = old.comment_id; end if;
  return null;
end $$;
drop trigger if exists comment_likes_trg on public.comment_likes;
create trigger comment_likes_trg after insert or delete on public.comment_likes
  for each row execute function public.trg_comment_likes();

create or replace function public.trg_follows() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    update public.profiles set following_count = following_count + 1 where id = new.follower_id;
    update public.profiles set followers_count = followers_count + 1 where id = new.following_id;
  else
    update public.profiles set following_count = greatest(following_count - 1, 0) where id = old.follower_id;
    update public.profiles set followers_count = greatest(followers_count - 1, 0) where id = old.following_id;
  end if;
  return null;
end $$;
drop trigger if exists follows_trg on public.follows;
create trigger follows_trg after insert or delete on public.follows
  for each row execute function public.trg_follows();

create or replace function public.trg_movie_likes() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then update public.movies set likes_count = likes_count + 1 where id = new.movie_id;
  else update public.movies set likes_count = greatest(likes_count - 1, 0) where id = old.movie_id; end if;
  return null;
end $$;
drop trigger if exists movie_likes_trg on public.movie_likes;
create trigger movie_likes_trg after insert or delete on public.movie_likes
  for each row execute function public.trg_movie_likes();

-- notifications
create or replace function public.trg_notify_follow() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.notifications (user_id, actor_id, type) values (new.following_id, new.follower_id, 'follow');
  return null;
end $$;
drop trigger if exists notify_follow_trg on public.follows;
create trigger notify_follow_trg after insert on public.follows
  for each row execute function public.trg_notify_follow();

create or replace function public.trg_notify_like() returns trigger
language plpgsql security definer set search_path = '' as $$
declare owner uuid;
begin
  select user_id into owner from public.posts where id = new.post_id;
  if owner is not null and owner <> new.user_id then
    insert into public.notifications (user_id, actor_id, type, post_id) values (owner, new.user_id, 'post_like', new.post_id);
  end if;
  return null;
end $$;
drop trigger if exists notify_like_trg on public.post_likes;
create trigger notify_like_trg after insert on public.post_likes
  for each row execute function public.trg_notify_like();

create or replace function public.trg_notify_comment() returns trigger
language plpgsql security definer set search_path = '' as $$
declare owner uuid; parent_owner uuid;
begin
  select user_id into owner from public.posts where id = new.post_id;
  if owner is not null and owner <> new.user_id then
    insert into public.notifications (user_id, actor_id, type, post_id, comment_id)
    values (owner, new.user_id, 'post_comment', new.post_id, new.id);
  end if;
  if new.parent_id is not null then
    select user_id into parent_owner from public.post_comments where id = new.parent_id;
    if parent_owner is not null and parent_owner <> new.user_id and parent_owner is distinct from owner then
      insert into public.notifications (user_id, actor_id, type, post_id, comment_id)
      values (parent_owner, new.user_id, 'comment_reply', new.post_id, new.id);
    end if;
  end if;
  return null;
end $$;
drop trigger if exists notify_comment_trg on public.post_comments;
create trigger notify_comment_trg after insert on public.post_comments
  for each row execute function public.trg_notify_comment();

-- chat: bump last_message_at
create or replace function public.trg_message_bump() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  update public.conversations set last_message_at = new.created_at where id = new.conversation_id;
  return null;
end $$;
drop trigger if exists message_bump_trg on public.messages;
create trigger message_bump_trg after insert on public.messages
  for each row execute function public.trg_message_bump();


-- =====================================================================
-- 6) USERNAME + NATIVE-AUTH ACCOUNT LOGIC
--    Supabase Auth owns passwords. Public SQL never stores/compares a login password.
-- =====================================================================
create or replace function public._username_format_error(u text) returns text
language plpgsql immutable set search_path = '' as $$
begin
  if u is null or u = '' then return 'empty'; end if;
  if u ~ '\s' then return 'spaces'; end if;
  if char_length(u) < 3 then return 'too_short'; end if;
  if char_length(u) > 24 then return 'too_long'; end if;
  if u !~ '^[a-z0-9_]+$' then return 'invalid_chars'; end if;
  if u like '\_%' or u like '%\_' then return 'edge_underscore'; end if;
  if position('__' in u) > 0 then return 'double_underscore'; end if;
  if u !~ '[a-z]' then return 'needs_letter'; end if;
  return null;
end $$;

create or replace function public._username_reserved(u text) returns boolean
language sql immutable set search_path = '' as $$
  select u = any (array[
    'admin','administrator','root','help','helpdesk','api','www','web','app','apps','home','login','logout',
    'signin','signup','register','settings','setting','about','terms','privacy','download','downloads','auxyapi'
  ])
$$;

-- Public preflight for registration. It intentionally exposes only availability,
-- never a user's email or other private information.
create function public.check_username(p_username text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  u text := lower(regexp_replace(trim(coalesce(p_username,'')), '^@+', ''));
  err text;
begin
  err := public._username_format_error(u);
  if err is not null then return jsonb_build_object('ok',false,'code',err); end if;
  if public._username_reserved(u) then return jsonb_build_object('ok',false,'code','reserved'); end if;
  if exists (select 1 from public.handles where handle=u)
     or exists (select 1 from public.profiles where lower(username)=u) then
    return jsonb_build_object('ok',false,'code','taken');
  end if;
  return jsonb_build_object('ok',true,'username',u);
end $$;

-- Username -> Auth email. The browser then calls the standard Supabase password endpoint.
-- This function must be callable before login, so it is granted to anon below.
create function public.resolve_username_login(p_username text)
returns table(email text, has_password boolean)
language sql
security definer
set search_path = ''
as $$
  select au.email, nullif(coalesce(au.encrypted_password,''),'') is not null
    from public.profiles p
    join auth.users au on au.id=p.id
   where lower(p.username)=lower(regexp_replace(trim(coalesce(p_username,'')), '^@+', ''))
   limit 1;
$$;

-- Attach a username to the currently authenticated account. The handles table
-- is a global namespace for future user/group/channel public names.
create function public.claim_username(p_username text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  uid uuid := auth.uid();
  u text := lower(regexp_replace(trim(coalesce(p_username,'')), '^@+', ''));
  chk jsonb;
  old text;
  newrole text;
begin
  if uid is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  select username, role into old, newrole from public.profiles where id=uid;
  if old is not null and old <> u then return jsonb_build_object('ok',false,'code','already_set'); end if;

  -- Idempotent: handle_new_user may already have claimed the username from signup metadata.
  if exists(select 1 from public.handles h where h.handle=u) then
    if exists(select 1 from public.handles h where h.handle=u and h.owner_type='user' and h.owner_id=uid) then
      update public.profiles set username=u, role=case when u = any(array['ali','support','auxy']) then 'owner' else role end, updated_at=now() where id=uid returning role into newrole;
      return jsonb_build_object('ok',true,'username',u,'role',coalesce(newrole,'user'));
    end if;
    return jsonb_build_object('ok',false,'code','taken');
  end if;

  chk := public.check_username(u);
  if not coalesce((chk->>'ok')::boolean,false) then return chk; end if;

  insert into public.handles(handle, owner_type, owner_id) values(u,'user',uid);
  update public.profiles set username=u, role=case when u = any(array['ali','support','auxy']) then 'owner' else role end, updated_at=now() where id=uid returning role into newrole;
  update public.user_private set username_changed_at=coalesce(username_changed_at,now()), updated_at=now() where user_id=uid;
  return jsonb_build_object('ok',true,'username',u,'role',coalesce(newrole,'user'));
exception when unique_violation then
  return jsonb_build_object('ok',false,'code','taken');
end $$;

-- Mark the Auth password as present after a successful native password login/recovery.
-- The client can only call this while authenticated.
create function public.sync_auth_password() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  uid uuid := auth.uid();
  em text;
begin
  if uid is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  select email into em from auth.users where id=uid;
  insert into public.user_private(user_id,email,recovery_email,password_set)
    values(uid,em,em,true)
    on conflict(user_id) do update set
      email=coalesce(em,public.user_private.email),
      recovery_email=case when em like '%@accounts.auxy.invalid' then public.user_private.recovery_email else coalesce(public.user_private.recovery_email,em) end,
      password_set=true,updated_at=now();
  return jsonb_build_object('ok',true);
end $$;

create function public.ensure_profile() returns void
language plpgsql security definer set search_path = '' as $$
declare
  uid uuid := auth.uid();
  au auth.users%rowtype;
  u text;
  nm text;
  av text;
begin
  if uid is null then return; end if;
  select * into au from auth.users where id=uid;
  if not found then return; end if;
  u := lower(regexp_replace(trim(coalesce(au.raw_user_meta_data ->> 'username','')), '^@+', ''));
  if public._username_format_error(u) is not null or public._username_reserved(u) then u := null; end if;
  nm := nullif(btrim(coalesce(au.raw_user_meta_data ->> 'display_name',au.raw_user_meta_data ->> 'full_name',au.raw_user_meta_data ->> 'name','')),'');
  av := nullif(btrim(coalesce(au.raw_user_meta_data ->> 'avatar_url',au.raw_user_meta_data ->> 'picture','')),'');
  insert into public.profiles(id,username,display_name,avatar_url,role)
    values(uid,u,nm,av,case when u = any(array['ali','support','auxy']) then 'owner' else 'user' end)
    on conflict(id) do update set
      username=coalesce(public.profiles.username,excluded.username),
      display_name=coalesce(public.profiles.display_name,excluded.display_name),
      avatar_url=coalesce(public.profiles.avatar_url,excluded.avatar_url),
      role=case when lower(coalesce(public.profiles.username,excluded.username,'')) = any(array['ali','support','auxy']) then 'owner' else public.profiles.role end;
  if u is not null then
    insert into public.handles(handle,owner_type,owner_id) values(u,'user',uid) on conflict(handle) do nothing;
  end if;
  insert into public.user_private(user_id,email,recovery_email,password_set,onboarded)
    values(uid,au.email,au.email,nullif(coalesce(au.encrypted_password,''),'') is not null,u is not null)
    on conflict(user_id) do update set
      email=coalesce(public.user_private.email,excluded.email),
      recovery_email=coalesce(public.user_private.recovery_email,excluded.recovery_email),
      password_set=public.user_private.password_set or excluded.password_set;
end $$;

create or replace function public.finish_onboarding() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid:=auth.uid();
begin
  if uid is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  if not exists(select 1 from public.profiles where id=uid and username is not null) then return jsonb_build_object('ok',false,'code','no_username'); end if;
  if not exists(select 1 from public.user_private where user_id=uid and password_set) then return jsonb_build_object('ok',false,'code','no_password'); end if;
  update public.user_private set onboarded=true,updated_at=now() where user_id=uid;
  return jsonb_build_object('ok',true);
end $$;

-- Update the editable profile fields used by the Settings page.
create function public.update_profile(p_display_name text, p_bio text, p_avatar_url text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  uid uuid := auth.uid();
  dn text := nullif(btrim(coalesce(p_display_name,'')), '');
  bv text := nullif(btrim(coalesce(p_bio,'')), '');
  av text := nullif(btrim(coalesce(p_avatar_url,'')), '');
begin
  if uid is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  if dn is not null and char_length(dn) > 40 then return jsonb_build_object('ok',false,'code','display_name_long'); end if;
  if bv is not null and char_length(bv) > 160 then return jsonb_build_object('ok',false,'code','bio_long'); end if;
  if av is not null and char_length(av) > 2048 then return jsonb_build_object('ok',false,'code','avatar_url_long'); end if;
  update public.profiles
     set display_name = dn,
         bio = bv,
         avatar_url = av,
         updated_at = now()
   where id = uid;
  if not found then return jsonb_build_object('ok',false,'code','profile_missing'); end if;
  return jsonb_build_object('ok',true);
end $$;

-- Native re-authenticated username change. Password verification happens in Supabase Auth
-- through the web client immediately before this RPC is called.
create function public.change_username_native(p_username text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  uid uuid:=auth.uid();
  u text:=lower(regexp_replace(trim(coalesce(p_username,'')),'^@+',''));
  old text; last_at timestamptz; chk jsonb; role_now text;
begin
  if uid is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  select username,username_changed_at into old,last_at from public.profiles p left join public.user_private up on up.user_id=p.id where p.id=uid;
  if old is not null and old=u then return jsonb_build_object('ok',true,'username',u); end if;
  if last_at is not null and last_at > now()-interval '14 days' then return jsonb_build_object('ok',false,'code','cooldown','retry_at',last_at+interval '14 days'); end if;
  chk:=public.check_username(u); if not coalesce((chk->>'ok')::boolean,false) then return chk; end if;
  perform pg_advisory_xact_lock(hashtextextended(u,0));
  delete from public.handles where owner_type='user' and owner_id=uid;
  insert into public.handles(handle,owner_type,owner_id) values(u,'user',uid);
  update public.profiles set username=u,updated_at=now() where id=uid returning role into role_now;
  update public.user_private set username_changed_at=now(),updated_at=now() where user_id=uid;
  return jsonb_build_object('ok',true,'username',u,'role',coalesce(role_now,'user'));
exception when unique_violation then
  return jsonb_build_object('ok',false,'code','taken');
end $$;

-- Native account deletion after a client-side password re-authentication.
create function public.delete_my_account_native() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid:=auth.uid();
begin
  if uid is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  delete from auth.users where id=uid;
  return jsonb_build_object('ok',true);
end $$;

-- Keep legacy application-password functions for old installations, but they are no longer
-- used by the login/onboarding/settings path.

create or replace function public.set_app_password(p_password text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); u text; err text;
begin
  if uid is null then return jsonb_build_object('ok', false, 'code', 'auth'); end if;
  select username into u from public.profiles where id=uid;
  if u is null then return jsonb_build_object('ok', false, 'code', 'no_username'); end if;
  if exists(select 1 from public.user_secrets where user_id=uid) then return jsonb_build_object('ok', false, 'code', 'already_set'); end if;
  err:=public._password_error(p_password,u);
  if err is not null then return jsonb_build_object('ok',false,'code',err); end if;
  insert into public.user_secrets(user_id,password_hash) values(uid,extensions.crypt(p_password,extensions.gen_salt('bf',10)));
  update public.user_private set password_set=true where user_id=uid;
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.verify_app_password(p_password text) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  return public._check_password(auth.uid(),p_password);
end $$;

create or replace function public.change_app_password(p_old text,p_new text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid:=auth.uid(); chk jsonb; u text; err text;
begin
  if uid is null then return jsonb_build_object('ok',false,'code','auth'); end if;
  chk:=public._check_password(uid,p_old); if not (chk->>'ok')::boolean then return chk; end if;
  select username into u from public.profiles where id=uid; err:=public._password_error(p_new,u);
  if err is not null then return jsonb_build_object('ok',false,'code',err); end if;
  update public.user_secrets set password_hash=extensions.crypt(p_new,extensions.gen_salt('bf',10)),updated_at=now() where user_id=uid;
  update public.user_private set password_set=true where user_id=uid;
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.change_username(p_username text,p_password text) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  return public.change_username_native(p_username);
end $$;

create or replace function public.bootstrap_me() returns jsonb
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); p public.profiles%rowtype; up public.user_private%rowtype; au auth.users%rowtype;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into au from auth.users where id=uid;
  insert into public.profiles(id,display_name,avatar_url,last_seen_at)
    values(uid,coalesce(au.raw_user_meta_data->>'display_name',au.raw_user_meta_data->>'full_name',au.raw_user_meta_data->>'name'),coalesce(au.raw_user_meta_data->>'avatar_url',au.raw_user_meta_data->>'picture'),now())
    on conflict(id) do update set last_seen_at=now();
  insert into public.user_private(user_id,email,recovery_email,password_set)
    values(uid,au.email,case when au.email like '%@accounts.auxy.invalid' then null else au.email end,coalesce(nullif(au.encrypted_password,''),null) is not null)
    on conflict(user_id) do update set email=coalesce(public.user_private.email,excluded.email),updated_at=now();
  select * into p from public.profiles where id=uid;
  select * into up from public.user_private where user_id=uid;
  return jsonb_build_object('profile',to_jsonb(p),'private',to_jsonb(up));
end $$;


create or replace function public.update_recovery_email(p_email text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare e text:=lower(trim(coalesce(p_email,'')));
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if e<>'' and e !~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' then raise exception 'invalid_email'; end if;
  update public.user_private set recovery_email=nullif(e,''),updated_at=now() where user_id=auth.uid();
  return jsonb_build_object('ok',true,'enabled',e<>'');
end $$;

create or replace function public.increment_movie_view(p_id uuid) returns void
language sql security definer set search_path = '' as $$
  update public.movies set views=views+1 where id=p_id and auth.uid() is not null
$$;

create or replace function public.increment_post_view(p_id uuid) returns void
language sql security definer set search_path = '' as $$
  update public.posts set views_count=views_count+1 where id=p_id and auth.uid() is not null
$$;


-- =====================================================================
-- 6) CHAT RPCs
-- =====================================================================
create or replace function public.toggle_post_like(p_post uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare is_on boolean;
begin
  if auth.uid() is null or public.is_banned() then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  select exists(select 1 from public.post_likes where post_id=p_post and user_id=auth.uid()) into is_on;
  if is_on then delete from public.post_likes where post_id=p_post and user_id=auth.uid(); else insert into public.post_likes(user_id,post_id) values(auth.uid(),p_post); end if;
  return jsonb_build_object('ok',true,'on',not is_on);
end $$;

create or replace function public.toggle_movie_like(p_movie uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare is_on boolean;
begin
  if auth.uid() is null or public.is_banned() then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  select exists(select 1 from public.movie_likes where movie_id=p_movie and user_id=auth.uid()) into is_on;
  if is_on then delete from public.movie_likes where movie_id=p_movie and user_id=auth.uid(); else insert into public.movie_likes(user_id,movie_id) values(auth.uid(),p_movie); end if;
  return jsonb_build_object('ok',true,'on',not is_on);
end $$;

create or replace function public.toggle_comment_like(p_comment uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare is_on boolean;
begin
  if auth.uid() is null or public.is_banned() then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  if not exists(select 1 from public.post_comments where id=p_comment) then return jsonb_build_object('ok',false,'code','not_found'); end if;
  select exists(select 1 from public.comment_likes where comment_id=p_comment and user_id=auth.uid()) into is_on;
  if is_on then delete from public.comment_likes where comment_id=p_comment and user_id=auth.uid(); else insert into public.comment_likes(user_id,comment_id) values(auth.uid(),p_comment); end if;
  return jsonb_build_object('ok',true,'on',not is_on);
end $$;


create or replace function public.start_direct_chat(p_user uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); k text; cid uuid;
begin
  if uid is null or public.is_banned() then raise exception 'not allowed'; end if;
  if p_user is null or p_user = uid
     or not exists (select 1 from public.profiles where id = p_user and username is not null) then
    raise exception 'invalid user';
  end if;
  k := least(uid::text, p_user::text) || ':' || greatest(uid::text, p_user::text);
  select id into cid from public.conversations where direct_key = k;
  if cid is null then
    insert into public.conversations (kind, created_by, direct_key) values ('direct', uid, k)
    on conflict (direct_key) do nothing returning id into cid;
    if cid is null then select id into cid from public.conversations where direct_key = k; end if;
    insert into public.conversation_members (conversation_id, user_id) values (cid, uid), (cid, p_user)
    on conflict do nothing;
  end if;
  return cid;
end $$;

create or replace function public.create_group_v2(p_title text,p_username text,p_description text,p_is_public boolean,p_members uuid[]) returns uuid
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); cid uuid; m uuid; u text:=lower(regexp_replace(trim(coalesce(p_username,'')),'^@+','')); token text:=encode(extensions.gen_random_bytes(12),'hex'); chk jsonb;
begin
  if uid is null or public.is_banned() then raise exception 'not allowed'; end if;
  if p_title is null or char_length(btrim(p_title)) not between 1 and 60 then raise exception 'bad title'; end if;
  if coalesce(array_length(p_members,1),0)>199 then raise exception 'too many members'; end if;
  if coalesce(p_is_public,false) then
    chk:=public.check_username(u); if not coalesce((chk->>'ok')::boolean,false) then raise exception 'username_not_available'; end if;
  else u:=null; end if;
  perform pg_advisory_xact_lock(hashtextextended(coalesce(u,uid::text||p_title),0));
  if u is not null and exists(select 1 from public.handles where handle=u) then raise exception 'username_taken'; end if;
  insert into public.conversations(kind,title,created_by,username,description,is_public,invite_token) values('group',btrim(p_title),uid,u,nullif(btrim(coalesce(p_description,'')),''),coalesce(p_is_public,false),token) returning id into cid;
  insert into public.conversation_members(conversation_id,user_id,role,permissions) values(cid,uid,'owner','{"send_messages":true,"delete_messages":true,"pin_messages":true,"invite_members":true,"manage_members":true,"manage_admins":true,"edit_info":true,"view_members":true,"manage_theme":true}'::jsonb);
  if u is not null then insert into public.handles(handle,owner_type,owner_id) values(u,'group',cid); end if;
  foreach m in array coalesce(p_members,'{}') loop
    if m<>uid and exists(select 1 from public.profiles where id=m and username is not null) then insert into public.conversation_members(conversation_id,user_id,role) values(cid,m,'member') on conflict do nothing; end if;
  end loop;
  return cid;
exception when unique_violation then raise exception 'username_taken';
end $$;

create or replace function public.join_group_public(p_conv uuid) returns uuid
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); k text; ok boolean;
begin
  if uid is null or public.is_banned() then raise exception 'not allowed'; end if;
  select kind,is_public into k,ok from public.conversations where id=p_conv;
  if k<>'group' or ok<>true then raise exception 'not_public_group'; end if;
  insert into public.conversation_members(conversation_id,user_id,role) values(p_conv,uid,'member') on conflict do update set status='active';
  return p_conv;
end $$;

create or replace function public.join_group_invite(p_token text) returns uuid
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); cid uuid; k text;
begin
  if uid is null or public.is_banned() then raise exception 'not allowed'; end if;
  select id,kind into cid,k from public.conversations where invite_token=trim(coalesce(p_token,''));
  if cid is null or k<>'group' then raise exception 'invalid invite'; end if;
  insert into public.conversation_members(conversation_id,user_id,role) values(cid,uid,'member') on conflict do update set status='active';
  return cid;
end $$;

create or replace function public.resolve_public_handle(p_handle text)
returns table(entity_type text,entity_id uuid,title text,username text,description text,avatar_url text,is_public boolean,member_count int)
language sql stable security definer set search_path='' as $$
  select 'user',p.id,p.display_name,p.username,p.bio,p.avatar_url,true,p.followers_count
    from public.profiles p where lower(p.username)=lower(regexp_replace(trim(coalesce(p_handle,'')),'^@+',''))
  union all
  select c.kind,c.id,c.title,c.username,c.description,c.avatar_url,c.is_public,(select count(*) from public.conversation_members cm where cm.conversation_id=c.id and cm.status='active')::int
    from public.conversations c where c.kind in ('group','channel') and c.is_public=true and lower(c.username)=lower(regexp_replace(trim(coalesce(p_handle,'')),'^@+',''))
  limit 1
$$;



-- create_group_v2 must exist before this SQL-language wrapper is parsed.
create or replace function public.create_group(p_title text,p_members uuid[]) returns uuid
language sql security definer set search_path='' as $$
  select public.create_group_v2(p_title,null,null,false,p_members)
$$;


-- ---------------------------------------------------------------------
-- Channels: global username namespace, public/private channels and invite links.
-- ---------------------------------------------------------------------
create or replace function public.create_channel(p_title text,p_username text,p_description text,p_is_public boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); cid uuid; u text:=nullif(lower(regexp_replace(trim(coalesce(p_username,'')),'^@+','')),''); token text:=encode(extensions.gen_random_bytes(12),'hex'); chk jsonb;
begin
  if uid is null or public.is_banned() then raise exception 'not allowed'; end if;
  if p_title is null or char_length(btrim(p_title)) not between 1 and 60 then raise exception 'bad title'; end if;
  if coalesce(p_is_public,false) then
    if u is null then raise exception 'public_username_required'; end if;
    chk:=public.check_username(u); if not coalesce((chk->>'ok')::boolean,false) then raise exception 'username_not_available'; end if;
    perform pg_advisory_xact_lock(hashtextextended(u,0));
    if exists(select 1 from public.handles where handle=u) then raise exception 'username_taken'; end if;
  else
    u:=null;
  end if;
  insert into public.conversations(kind,title,created_by,username,description,is_public,invite_token)
    values('channel',btrim(p_title),uid,u,nullif(btrim(coalesce(p_description,'')),''),coalesce(p_is_public,false),token) returning id into cid;
  if u is not null then insert into public.handles(handle,owner_type,owner_id) values(u,'channel',cid); end if;
  insert into public.conversation_members(conversation_id,user_id,role,permissions)
    values(cid,uid,'owner','{"send_messages":true,"delete_messages":true,"pin_messages":true,"invite_members":true,"manage_members":true,"manage_admins":true,"edit_info":true,"view_members":true,"manage_theme":true}'::jsonb);
  return cid;
exception when unique_violation then raise exception 'username_taken';
end $$;

create or replace function public.search_channels(p_q text, p_limit int default 30)
returns table(conv_id uuid,title text,username text,description text,avatar_url text,member_count int,is_public boolean)
language sql stable security definer set search_path = '' as $$
  select c.id,c.title,c.username,c.description,c.avatar_url,
         (select count(*) from public.conversation_members cm where cm.conversation_id=c.id)::int,
         c.is_public
    from public.conversations c
   where c.kind='channel' and c.is_public=true
     and (coalesce(trim(p_q),'')='' or c.username ilike trim(p_q)||'%' or c.title ilike '%'||trim(p_q)||'%')
   order by c.created_at desc
   limit least(greatest(coalesce(p_limit,30),1),50)
$$;

create or replace function public.join_channel(p_conv uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare uid uuid:=auth.uid(); k text;
begin
  if uid is null or public.is_banned() then raise exception 'not allowed'; end if;
  select kind into k from public.conversations where id=p_conv;
  if k <> 'channel' then raise exception 'not a channel'; end if;
  if not exists(select 1 from public.conversations where id=p_conv and is_public=true) then raise exception 'private channel'; end if;
  insert into public.conversation_members(conversation_id,user_id,role) values(p_conv,uid,'member') on conflict do nothing;
  return p_conv;
end $$;

create or replace function public.join_channel_invite(p_token text) returns uuid
language plpgsql security definer set search_path = '' as $$
declare uid uuid:=auth.uid(); cid uuid;
begin
  if uid is null or public.is_banned() then raise exception 'not allowed'; end if;
  select id into cid from public.conversations where kind='channel' and invite_token=trim(coalesce(p_token,''));
  if cid is null then raise exception 'invalid invite'; end if;
  insert into public.conversation_members(conversation_id,user_id,role) values(cid,uid,'member') on conflict do nothing;
  return cid;
end $$;

create or replace function public.set_conversation_handle(p_conv uuid,p_username text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); u text:=lower(regexp_replace(trim(coalesce(p_username,'')),'^@+','')); k text; role_now text; old text; chk jsonb;
begin
  select c.kind,cm.role,c.username into k,role_now,old from public.conversations c join public.conversation_members cm on cm.conversation_id=c.id
   where c.id=p_conv and cm.user_id=uid and cm.status='active';
  if uid is null or k not in ('group','channel') then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  if not public.conv_can_edit_info(p_conv) then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  chk:=public.check_username(u); if not coalesce((chk->>'ok')::boolean,false) then return chk; end if;
  perform pg_advisory_xact_lock(hashtextextended(u,0));
  if exists(select 1 from public.handles h where h.handle=u and not(h.owner_type=k and h.owner_id=p_conv)) then return jsonb_build_object('ok',false,'code','taken'); end if;
  if old is not null then delete from public.handles where owner_type=k and owner_id=p_conv; end if;
  update public.conversations set username=u,is_public=true where id=p_conv;
  insert into public.handles(handle,owner_type,owner_id) values(u,k,p_conv);
  return jsonb_build_object('ok',true,'username',u);
exception when unique_violation then return jsonb_build_object('ok',false,'code','taken');
end $$;



create or replace function public.mark_read(p_conv uuid) returns void
language sql security definer set search_path = '' as $$
  update public.conversation_members set last_read_at = now()
   where conversation_id = p_conv and user_id = auth.uid()
$$;

create or replace function public.my_conversations()
returns table(conv_id uuid,kind text,title text,avatar_url text,other_id uuid,other_display_name text,other_username text,last_body text,last_media text,last_at timestamptz,last_sender uuid,unread int,member_count int,muted boolean)
language sql stable security definer set search_path='' as $$
  select c.id,c.kind,c.title,c.avatar_url,o.id,o.display_name,o.username,
         lm.body,lm.media_url,coalesce(lm.created_at,c.created_at),lm.sender_id,
         (select count(*) from public.messages m where m.conversation_id=c.id and m.created_at>cm.last_read_at and m.sender_id<>auth.uid() and m.deleted_at is null)::int,
         (select count(*) from public.conversation_members x where x.conversation_id=c.id and x.status='active')::int,cm.muted
    from public.conversation_members cm
    join public.conversations c on c.id=cm.conversation_id
    left join lateral (
      select p.id,p.display_name,p.username
        from public.profiles p
       where p.id=(select x.user_id from public.conversation_members x where x.conversation_id=c.id and x.user_id<>auth.uid() and x.status='active' and c.kind='direct' limit 1)
    ) o on true
    left join lateral (select body,media_url,created_at,sender_id from public.messages where conversation_id=c.id and deleted_at is null order by created_at desc limit 1) lm on true
   where cm.user_id=auth.uid() and cm.status='active'
   order by coalesce(lm.created_at,c.created_at) desc
$$;


-- =====================================================================
-- 7) AUXY CHAT PERMISSIONS / SAVED / DEVICES / PUBLIC LINKS / SYSTEM ACCOUNT
-- =====================================================================

-- Normalise old group/channel creators to explicit owners and hydrate defaults.
update public.conversation_members cm
set role='owner', permissions='{"send_messages":true,"delete_messages":true,"pin_messages":true,"invite_members":true,"manage_members":true,"manage_admins":true,"edit_info":true,"view_members":true,"manage_theme":true}'::jsonb
from public.conversations c
where c.id=cm.conversation_id and c.created_by=cm.user_id and c.kind in ('group','channel') and cm.role <> 'owner';

create or replace function public.is_conv_manager(p_conv uuid) returns boolean
language sql stable security definer set search_path='' as $$
  select exists(select 1 from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active' and cm.role in ('owner','admin'));
$$;

create or replace function public.conv_can_send_message(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare k text; r text; perms jsonb;
begin
  select c.kind into k from public.conversations c where c.id=p_conv;
  if k is null then return false; end if;
  if k='direct' or k='group' then
    return exists(select 1 from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active');
  end if;
  if k='channel' then
    select cm.role,cm.permissions into r,perms from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
    return r='owner' or (r='admin' and coalesce((perms->>'send_messages')::boolean,false));
  end if;
  return false;
end $$;

create or replace function public.conv_can_invite_members(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare k text; r text; perms jsonb;
begin
  select c.kind into k from public.conversations c where c.id=p_conv;
  if k not in ('group','channel') then return false; end if;
  select cm.role,cm.permissions into r,perms from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
  return r='owner' or (r='admin' and coalesce((perms->>'invite_members')::boolean,false));
end $$;

create or replace function public.conv_can_manage_theme(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare k text; r text; perms jsonb;
begin
  select c.kind into k from public.conversations c where c.id=p_conv;
  if k not in ('group','channel') then return false; end if;
  select cm.role,cm.permissions into r,perms from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
  return r='owner' or (r='admin' and coalesce((perms->>'manage_theme')::boolean,false));
end $$;

create or replace function public.conv_can_edit_info(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare k text; r text; perms jsonb;
begin
  select c.kind into k from public.conversations c where c.id=p_conv;
  if k not in ('group','channel') then return false; end if;
  select cm.role,cm.permissions into r,perms from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
  return r='owner' or (r='admin' and coalesce((perms->>'edit_info')::boolean,false));
end $$;

create or replace function public.conv_can_pin_messages(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare k text; r text; perms jsonb;
begin
  select c.kind into k from public.conversations c where c.id=p_conv;
  if k not in ('group','channel') then return false; end if;
  select cm.role,cm.permissions into r,perms from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
  return r='owner' or (r='admin' and coalesce((perms->>'pin_messages')::boolean,false));
end $$;

create or replace function public.conv_can_manage_members(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare r text; perms jsonb; k text;
begin
  select c.kind into k from public.conversations c where c.id=p_conv;
  if k not in ('group','channel') then return false; end if;
  select cm.role,cm.permissions into r,perms from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
  return r='owner' or (r='admin' and coalesce((perms->>'manage_members')::boolean,false));
end $$;

create or replace function public.conv_can_manage_admins(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare r text; perms jsonb;
begin
  select cm.role,cm.permissions into r,perms from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
  return r='owner' or (r='admin' and coalesce((perms->>'manage_admins')::boolean,false));
end $$;

create or replace function public.conv_can_view_members(p_conv uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare k text; pub boolean; r text;
begin
  select c.kind,coalesce(c.is_public,false) into k,pub from public.conversations c where c.id=p_conv;
  select cm.role into r from public.conversation_members cm where cm.conversation_id=p_conv and cm.user_id=auth.uid() and cm.status='active';
  if r is null then return false; end if;
  if k='group' and pub=false then return true; end if;
  return r in ('owner','admin');
end $$;

create or replace function public.get_conversation_members(p_conv uuid)
returns table(user_id uuid, username text, display_name text, avatar_url text, role text, permissions jsonb, joined_at timestamptz, last_seen_at timestamptz)
language plpgsql security definer set search_path='' as $$
begin
  if not public.conv_can_view_members(p_conv) then raise exception 'members_not_visible'; end if;
  return query
    select cm.user_id,p.username,p.display_name,p.avatar_url,cm.role,cm.permissions,cm.joined_at,ud.last_seen_at
    from public.conversation_members cm
    join public.profiles p on p.id=cm.user_id
    left join lateral (select last_seen_at from public.user_devices where user_id=cm.user_id and revoked_at is null order by last_seen_at desc limit 1) ud on true
    where cm.conversation_id=p_conv and cm.status='active'
    order by case when cm.role='owner' then 0 when cm.role='admin' then 1 else 2 end, cm.joined_at asc;
end $$;

create or replace function public.set_member_role(p_conv uuid,p_user uuid,p_role text,p_permissions jsonb default '{}'::jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
declare k text; target_role text; actor_role text; actor_perms jsonb; base jsonb;
begin
  select kind into k from public.conversations where id=p_conv;
  if k not in ('group','channel') then return jsonb_build_object('ok',false,'code','not_manageable'); end if;
  if not public.conv_can_manage_admins(p_conv) then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  if p_user=auth.uid() then return jsonb_build_object('ok',false,'code','self'); end if;
  if p_role not in ('admin','member') then return jsonb_build_object('ok',false,'code','bad_role'); end if;
  if not exists(select 1 from public.profiles where id=p_user and username is not null) then return jsonb_build_object('ok',false,'code','user_not_found'); end if;
  if exists(select 1 from public.conversation_members where conversation_id=p_conv and user_id=p_user and role='owner') then return jsonb_build_object('ok',false,'code','owner_protected'); end if;
  if k='channel' then
    if not exists(select 1 from public.conversation_members where conversation_id=p_conv and user_id=p_user) then
      insert into public.conversation_members(conversation_id,user_id,role,permissions) values(p_conv,p_user,p_role,coalesce(p_permissions,'{}'::jsonb));
    else
      update public.conversation_members set role=p_role,permissions=coalesce(p_permissions,'{}'::jsonb),status='active' where conversation_id=p_conv and user_id=p_user;
    end if;
  else
    insert into public.conversation_members(conversation_id,user_id,role,permissions) values(p_conv,p_user,p_role,coalesce(p_permissions,'{}'::jsonb))
    on conflict(conversation_id,user_id) do update set role=excluded.role,permissions=excluded.permissions,status='active';
  end if;
  return jsonb_build_object('ok',true,'role',p_role);
end $$;

create or replace function public.set_member_permissions(p_conv uuid,p_user uuid,p_permissions jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  if not public.conv_can_manage_admins(p_conv) then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  if exists(select 1 from public.conversation_members where conversation_id=p_conv and user_id=p_user and role='owner') then return jsonb_build_object('ok',false,'code','owner_protected'); end if;
  update public.conversation_members set permissions=coalesce(p_permissions,'{}'::jsonb) where conversation_id=p_conv and user_id=p_user and status='active';
  if not found then return jsonb_build_object('ok',false,'code','member_not_found'); end if;
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.add_channel_admin(p_conv uuid,p_user uuid,p_permissions jsonb default '{"send_messages":false,"delete_messages":false,"pin_messages":false,"invite_members":false,"manage_members":false,"manage_admins":false,"edit_info":false,"view_members":true,"manage_theme":false}'::jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  if not exists(select 1 from public.conversations where id=p_conv and kind='channel') then return jsonb_build_object('ok',false,'code','not_channel'); end if;
  return public.set_member_role(p_conv,p_user,'admin',p_permissions);
end $$;

create or replace function public.set_conversation_theme(p_conv uuid,p_theme jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  if not public.conv_can_manage_theme(p_conv) then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  update public.conversations set theme=coalesce(p_theme,'{}'::jsonb),updated_at=now() where id=p_conv;
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.save_message(p_message uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  if not exists(select 1 from public.messages m join public.conversation_members cm on cm.conversation_id=m.conversation_id and cm.user_id=auth.uid() and cm.status='active' where m.id=p_message) then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  if not exists (select 1 from public.saved_messages where user_id=auth.uid() and message_id=p_message) then
    insert into public.saved_messages(user_id,message_id) values(auth.uid(),p_message);
  end if;
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.unsave_message(p_message uuid) returns jsonb
language sql security definer set search_path='' as $$
  delete from public.saved_messages where user_id=auth.uid() and message_id=p_message; select jsonb_build_object('ok',true);
$$;

create or replace function public.list_saved_messages(p_limit int default 100)
returns table(message_id uuid,conversation_id uuid,sender_id uuid,body text,media_url text,media_type text,created_at timestamptz,conversation_kind text,conversation_title text)
language sql stable security definer set search_path='' as $$
  select m.id,m.conversation_id,m.sender_id,m.body,m.media_url,m.media_type,m.created_at,c.kind,c.title
  from public.saved_messages s join public.messages m on m.id=s.message_id join public.conversations c on c.id=m.conversation_id
  where s.user_id=auth.uid() order by s.created_at desc limit least(greatest(coalesce(p_limit,100),1),200)
$$;

create or replace function public.toggle_message_reaction(p_message uuid,p_reaction text) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  if not exists(select 1 from public.messages m join public.conversation_members cm on cm.conversation_id=m.conversation_id and cm.user_id=auth.uid() and cm.status='active' where m.id=p_message) then return jsonb_build_object('ok',false,'code','not_allowed'); end if;
  if exists(select 1 from public.message_reactions where message_id=p_message and user_id=auth.uid() and reaction=p_reaction) then delete from public.message_reactions where message_id=p_message and user_id=auth.uid() and reaction=p_reaction; return jsonb_build_object('ok',true,'on',false); end if;
  insert into public.message_reactions(message_id,user_id,reaction) values(p_message,auth.uid(),left(p_reaction,32));
  return jsonb_build_object('ok',true,'on',true);
end $$;


create or replace function public.create_series(p_title text,p_description text,p_year int,p_genres text[],p_maturity text,p_poster_url text,p_backdrop_url text,p_featured boolean,p_published boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); sid uuid;
begin
  if not public.is_publisher() then raise exception 'not_allowed'; end if;
  insert into public.series(title,description,year,genres,maturity,poster_url,backdrop_url,featured,published,created_by) values(trim(p_title),nullif(trim(coalesce(p_description,'')),''),p_year,coalesce(p_genres,'{}'),coalesce(p_maturity,'all'),nullif(trim(coalesce(p_poster_url,'')),''),nullif(trim(coalesce(p_backdrop_url,'')),''),coalesce(p_featured,false),coalesce(p_published,true),uid) returning id into sid;
  return sid;
end $$;

create or replace function public.create_season(p_series uuid,p_number int,p_title text) returns uuid
language plpgsql security definer set search_path='' as $$
declare sid uuid;
begin
  if not public.is_publisher() then raise exception 'not_allowed'; end if;
  insert into public.seasons(series_id,season_number,title) values(p_series,p_number,nullif(trim(coalesce(p_title,'')),'')) returning id into sid; return sid;
end $$;

create or replace function public.create_episode(p_season uuid,p_number int,p_title text,p_description text,p_duration int,p_poster_url text,p_video_url text,p_video_kind text,p_published boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare eid uuid;
begin
  if not public.is_publisher() then raise exception 'not_allowed'; end if;
  insert into public.episodes(season_id,episode_number,title,description,duration_minutes,poster_url,video_url,video_kind,published) values(p_season,p_number,trim(p_title),nullif(trim(coalesce(p_description,'')),''),p_duration,nullif(trim(coalesce(p_poster_url,'')),''),trim(p_video_url),coalesce(p_video_kind,'url'),coalesce(p_published,true)) returning id into eid; return eid;
end $$;

-- =====================================================================
-- 8) OWNER / ADMIN RPCs
-- =====================================================================
create or replace function public.admin_stats() returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_staff() then raise exception 'not allowed'; end if;
  return jsonb_build_object(
    'users',        (select count(*) from public.profiles where username is not null),
    'users_today',  (select count(*) from public.profiles where created_at > now() - interval '1 day'),
    'banned',       (select count(*) from public.profiles where is_banned),
    'movies',       (select count(*) from public.movies),
    'posts',        (select count(*) from public.posts),
    'comments',     (select count(*) from public.post_comments) + (select count(*) from public.movie_comments),
    'messages',     (select count(*) from public.messages),
    'reports_open', (select count(*) from public.reports where status = 'open'),
    'ads_active',   (select count(*) from public.ads where active),
    'ad_views',     (select count(*) from public.ad_views)
  );
end $$;

create or replace function public.admin_list_users(p_q text, p_limit int, p_offset int)
returns table (id uuid, username text, display_name text, avatar_url text, role text,
               is_banned boolean, ban_reason text, email text, created_at timestamptz, posts_count int)
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  return query
    select p.id, p.username, p.display_name, p.avatar_url, p.role, p.is_banned, p.ban_reason,
           u.email, p.created_at, p.posts_count
      from public.profiles p
      left join public.user_private u on u.user_id = p.id
     where coalesce(p_q, '') = ''
        or p.username ilike '%' || p_q || '%'
        or p.display_name ilike '%' || p_q || '%'
        or u.email ilike '%' || p_q || '%'
     order by p.created_at desc
     limit least(coalesce(p_limit, 30), 100) offset greatest(coalesce(p_offset, 0), 0);
end $$;

create or replace function public.admin_set_role(p_user uuid, p_role text) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  if p_user = auth.uid() then return jsonb_build_object('ok', false, 'code', 'self'); end if;
  if p_role not in ('user','moderator','publisher','owner') then return jsonb_build_object('ok', false, 'code', 'bad_role'); end if;
  if exists (select 1 from public.profiles where id = p_user and lower(username) = any(array['ali','support','auxy'])) and p_role <> 'owner' then
    return jsonb_build_object('ok', false, 'code', 'protected_admin');
  end if;
  update public.profiles set role = p_role where id = p_user;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_set_ban(p_user uuid, p_banned boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  if p_user = auth.uid() then return jsonb_build_object('ok', false, 'code', 'self'); end if;
  if exists (select 1 from public.profiles where id = p_user and (role = 'owner' or lower(username) = any(array['ali','support','auxy']))) then
    return jsonb_build_object('ok', false, 'code', 'protected_admin');
  end if;
  update public.profiles set is_banned = p_banned, ban_reason = case when p_banned then left(p_reason, 300) else null end
   where id = p_user;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_reset_password(p_user uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  delete from public.user_secrets where user_id = p_user;
  update public.user_private set password_set = false where user_id = p_user;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_delete_user(p_user uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  if p_user = auth.uid() then return jsonb_build_object('ok', false, 'code', 'self'); end if;
  if exists (select 1 from public.profiles where id = p_user and (role = 'owner' or lower(username) = any(array['ali','support','auxy']))) then
    return jsonb_build_object('ok', false, 'code', 'protected_admin');
  end if;
  delete from auth.users where id = p_user;
  return jsonb_build_object('ok', true);
end $$;


-- Backward-compatible override: regular member management is group-only; channels add admins only.
create or replace function public.add_group_members(p_conv uuid, p_members uuid[]) returns void
language plpgsql security definer set search_path='' as $$
declare m uuid;
begin
  if not public.conv_can_invite_members(p_conv) then raise exception 'not_allowed'; end if;
  if not exists(select 1 from public.conversations where id=p_conv and kind='group') then raise exception 'group_only'; end if;
  foreach m in array coalesce(p_members,'{}') loop
    if m<>auth.uid() and exists(select 1 from public.profiles where id=m and username is not null) then
      insert into public.conversation_members(conversation_id,user_id,role,permissions) values(p_conv,m,'member','{"send_messages":true}'::jsonb) on conflict(conversation_id,user_id) do update set status='active';
    end if;
  end loop;
end $$;

create or replace function public.leave_conversation(p_conv uuid) returns void
language plpgsql security definer set search_path='' as $$
begin
  update public.conversation_members set status='left' where conversation_id=p_conv and user_id=auth.uid() and role<>'owner';
end $$;



-- =====================================================================
-- Final feature/security overrides
-- =====================================================================
create or replace function public.submit_report(p_target_type text,p_target_id uuid,p_category text,p_reason text,p_details text default null) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_target_type not in ('post','post_comment','movie_comment','user','movie','message','group','channel','series','episode') then raise exception 'bad_target'; end if;
  if p_reason is null or char_length(btrim(p_reason)) not between 1 and 500 then raise exception 'bad_reason'; end if;
  if exists(select 1 from public.reports where reporter_id=auth.uid() and target_type=p_target_type and target_id=p_target_id and status='open') then
    return jsonb_build_object('ok',true,'duplicate',true);
  end if;
  insert into public.reports(reporter_id,target_type,target_id,category,reason,details,metadata) values(auth.uid(),p_target_type,p_target_id,coalesce(nullif(btrim(p_category),''),'other'),btrim(p_reason),nullif(btrim(coalesce(p_details,'')),''),'{}'::jsonb);
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.list_my_devices() returns table(id uuid,device_key text,label text,user_agent text,last_seen_at timestamptz,created_at timestamptz,revoked_at timestamptz,is_current boolean)
language sql stable security definer set search_path='' as $$
  select d.id,d.device_key,d.label,d.user_agent,d.last_seen_at,d.created_at,d.revoked_at,false from public.user_devices d where d.user_id=auth.uid() order by d.revoked_at nulls first,d.last_seen_at desc
$$;

create or replace function public.register_device(p_device_key text,p_label text,p_user_agent text) returns uuid
language plpgsql security definer set search_path='' as $$
declare did uuid;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_device_key is null or char_length(p_device_key) < 12 or char_length(p_device_key) > 128 then raise exception 'bad_device'; end if;
  insert into public.user_devices(user_id,device_key,label,user_agent,last_seen_at,revoked_at) values(auth.uid(),p_device_key,left(coalesce(p_label,'دستگاه'),80),left(coalesce(p_user_agent,''),500),now(),null)
    on conflict(user_id,device_key) do update set label=excluded.label,user_agent=excluded.user_agent,last_seen_at=now(),revoked_at=null returning id into did;
  return did;
end $$;

create or replace function public.revoke_device(p_device uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  update public.user_devices set revoked_at=now() where id=p_device and user_id=auth.uid();
  return jsonb_build_object('ok',found);
end $$;

create or replace function public.is_current_device_revoked(p_device_key text) returns boolean
language sql stable security definer set search_path='' as $$
  select exists(select 1 from public.user_devices where user_id=auth.uid() and device_key=p_device_key and revoked_at is not null)
$$;

create or replace function public.ensure_auxy_welcome() returns uuid
language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); cid uuid; mid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  insert into public.conversations(kind,title,avatar_url,system_key,created_by,is_public,message_limit) values('system','Auxy','/auxy-black.png','welcome:'||uid::text,null,false,4000)
    on conflict(system_key) do nothing returning id into cid;
  if cid is null then select id into cid from public.conversations where system_key='welcome:'||uid::text; end if;
  insert into public.conversation_members(conversation_id,user_id,role,permissions) values(cid,uid,'member','{"send_messages":false,"view_members":false}'::jsonb) on conflict do nothing;
  insert into public.messages(conversation_id,sender_id,body,media_type)
  select cid,null,
         case when exists(select 1 from public.messages where conversation_id=cid)
              then 'ورود جدید به حساب Auxy ثبت شد. اگر این ورود توسط تو نبوده، از تنظیمات > امنیت و دستگاه‌ها نشست‌های ناشناس را خاتمه بده.'
              else 'به Auxy خوش آمدی. اینجا پیام‌های رسمی سیستم، امنیت حساب و اعلان‌های مهم برایت ارسال می‌شود.'
         end,
         'none';
  return cid;
end $$;

-- Ensure owner/admin roles are represented explicitly on existing conversations.
update public.conversation_members cm set role='owner'
 from public.conversations c where c.id=cm.conversation_id and c.created_by=cm.user_id and c.kind in ('group','channel','system') and cm.role <> 'owner';

-- Keep RLS policy references compatible with active membership and scoped send permission.
-- =====================================================================
-- 8) ROW LEVEL SECURITY
-- =====================================================================
alter table public.profiles             enable row level security;
alter table public.user_private         enable row level security;
alter table public.user_secrets         enable row level security;
alter table public.reserved_usernames   enable row level security;
alter table public.handles               enable row level security;
alter table public.movies               enable row level security;
alter table public.movie_likes          enable row level security;
alter table public.movie_comments       enable row level security;
alter table public.my_list              enable row level security;
alter table public.watch_progress       enable row level security;
alter table public.ads                  enable row level security;
alter table public.ad_views             enable row level security;
alter table public.posts                enable row level security;
alter table public.post_likes           enable row level security;
alter table public.post_saves           enable row level security;
alter table public.post_comments        enable row level security;
alter table public.comment_likes        enable row level security;
alter table public.follows              enable row level security;
alter table public.notifications        enable row level security;
alter table public.reports              enable row level security;
alter table public.conversations        enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages             enable row level security;
alter table public.series                enable row level security;
alter table public.seasons               enable row level security;
alter table public.episodes              enable row level security;
alter table public.saved_messages        enable row level security;
alter table public.message_reactions     enable row level security;
alter table public.user_devices          enable row level security;

-- drop old/first-version policies so this file can be re-run
do $$
declare r record;
begin
  for r in select schemaname, tablename, policyname from pg_policies where schemaname = 'public' loop
    execute format('drop policy if exists %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

-- profiles: everyone signed in sees finished profiles; you always see your own
create policy p_profiles_select on public.profiles for select to authenticated
  using (username is not null or id = (select auth.uid()));

-- user_private: own row only (settings are the only writable column)
create policy p_private_select on public.user_private for select to authenticated
  using (user_id = (select auth.uid()));
create policy p_private_update on public.user_private for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- movies
create policy p_movies_select on public.movies for select to authenticated
  using (published or public.is_publisher());
create policy p_movies_insert on public.movies for insert to authenticated
  with check (public.is_publisher() and created_by = (select auth.uid()));
create policy p_movies_update on public.movies for update to authenticated
  using (public.is_publisher()) with check (public.is_publisher());
create policy p_movies_delete on public.movies for delete to authenticated
  using (public.is_publisher());

create policy p_movie_likes_all on public.movie_likes for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

create policy p_movie_comments_select on public.movie_comments for select to authenticated using (true);
create policy p_movie_comments_insert on public.movie_comments for insert to authenticated
  with check (user_id = (select auth.uid()) and not public.is_banned());
create policy p_movie_comments_delete on public.movie_comments for delete to authenticated
  using (user_id = (select auth.uid()) or public.is_staff());

create policy p_my_list_all on public.my_list for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy p_watch_all on public.watch_progress for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- ads
create policy p_ads_select on public.ads for select to authenticated using (active or public.is_owner());
create policy p_ads_insert on public.ads for insert to authenticated with check (public.is_owner());
create policy p_ads_update on public.ads for update to authenticated using (public.is_owner()) with check (public.is_owner());
create policy p_ads_delete on public.ads for delete to authenticated using (public.is_owner());
create policy p_ad_views_insert on public.ad_views for insert to authenticated with check (user_id = (select auth.uid()));
create policy p_ad_views_select on public.ad_views for select to authenticated using (public.is_owner());

-- feed
create policy p_posts_select on public.posts for select to authenticated using (true);
create policy p_posts_insert on public.posts for insert to authenticated
  with check (user_id = (select auth.uid()) and not public.is_banned());
create policy p_posts_update on public.posts for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy p_posts_delete on public.posts for delete to authenticated
  using (user_id = (select auth.uid()) or public.is_staff());

create policy p_post_likes_all on public.post_likes for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()) and not public.is_banned());
create policy p_post_saves_all on public.post_saves for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

create policy p_post_comments_select on public.post_comments for select to authenticated using (true);
create policy p_post_comments_insert on public.post_comments for insert to authenticated
  with check (user_id = (select auth.uid()) and not public.is_banned());
create policy p_post_comments_delete on public.post_comments for delete to authenticated
  using (user_id = (select auth.uid()) or public.is_staff());

create policy p_comment_likes_all on public.comment_likes for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()) and not public.is_banned());

create policy p_follows_select on public.follows for select to authenticated using (true);
create policy p_follows_insert on public.follows for insert to authenticated
  with check (follower_id = (select auth.uid()) and not public.is_banned());
create policy p_follows_delete on public.follows for delete to authenticated
  using (follower_id = (select auth.uid()));

create policy p_notif_select on public.notifications for select to authenticated using (user_id = (select auth.uid()));
create policy p_notif_update on public.notifications for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy p_notif_delete on public.notifications for delete to authenticated using (user_id = (select auth.uid()));

create policy p_reports_insert on public.reports for insert to authenticated with check (reporter_id = (select auth.uid()));
create policy p_reports_select on public.reports for select to authenticated using (public.is_staff());
create policy p_reports_update on public.reports for update to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- chat (rows are created by the RPCs above)
create policy p_conv_select on public.conversations for select to authenticated using (public.is_conv_member(id));
create policy p_members_select on public.conversation_members for select to authenticated using (public.conv_can_view_members(conversation_id));
drop policy if exists p_members_update on public.conversation_members;
create policy p_msg_select on public.messages for select to authenticated using (public.is_conv_member(conversation_id));
create policy p_msg_insert on public.messages for insert to authenticated
  with check (sender_id = (select auth.uid()) and public.conv_can_send_message(conversation_id) and not public.is_banned()
              and char_length(coalesce(body,'')) <= coalesce((select message_limit from public.conversations c where c.id=conversation_id),4000));
create policy p_msg_update on public.messages for update to authenticated
  using (sender_id = (select auth.uid()) or (public.is_conv_manager(conversation_id) and coalesce((select (permissions->>'delete_messages')::boolean from public.conversation_members cm where cm.conversation_id=messages.conversation_id and cm.user_id=auth.uid()),false)))
  with check (sender_id = (select auth.uid()) or (public.is_conv_manager(conversation_id) and coalesce((select (permissions->>'delete_messages')::boolean from public.conversation_members cm where cm.conversation_id=messages.conversation_id and cm.user_id=auth.uid()),false)));


-- Series / episodes: published content is readable by signed-in users; publishers/owners manage it.
create policy p_series_select on public.series for select to authenticated using (published = true or public.is_publisher());
create policy p_series_insert on public.series for insert to authenticated with check (public.is_publisher());
create policy p_series_update on public.series for update to authenticated using (public.is_publisher());
create policy p_series_delete on public.series for delete to authenticated using (public.is_publisher());
create policy p_seasons_select on public.seasons for select to authenticated using (exists(select 1 from public.series s where s.id=series_id and (s.published=true or public.is_publisher())));
create policy p_seasons_write on public.seasons for all to authenticated using (public.is_publisher()) with check (public.is_publisher());
create policy p_episodes_select on public.episodes for select to authenticated using (exists(select 1 from public.seasons sn join public.series s on s.id=sn.series_id where sn.id=season_id and (s.published=true or public.is_publisher())));
create policy p_episodes_write on public.episodes for all to authenticated using (public.is_publisher()) with check (public.is_publisher());

create policy p_saved_select on public.saved_messages for select to authenticated using (user_id=auth.uid());
create policy p_saved_write on public.saved_messages for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy p_reactions_select on public.message_reactions for select to authenticated using (public.is_conv_member((select conversation_id from public.messages where id=message_id)));
create policy p_reactions_write on public.message_reactions for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid() and public.is_conv_member((select conversation_id from public.messages where id=message_id)));
create policy p_devices_select on public.user_devices for select to authenticated using (user_id=auth.uid());
create policy p_devices_update on public.user_devices for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create policy episode_watch_progress_user on public.episode_watch_progress for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

-- =====================================================================
-- 9) TABLE PRIVILEGES  (anon gets nothing; signed-in users get only what they need)
-- =====================================================================
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

grant select (id, username, display_name, avatar_url, bio, role, is_banned,
              followers_count, following_count, posts_count, created_at) on public.profiles to authenticated;
grant select on public.user_private to authenticated;
grant update (settings) on public.user_private to authenticated;

grant select on public.movies to authenticated;
grant insert (title, original_title, original_language, description, year, duration_minutes, genres, maturity, poster_url, backdrop_url,
              video_url, video_kind, featured, published, created_by, country, release_date, director, cast_names, writers,
              rating, imdb_id, tmdb_id, trailer_url, subtitle_languages, audio_languages, quality, tags) on public.movies to authenticated;
grant update (title, original_title, original_language, description, year, duration_minutes, genres, maturity, poster_url, backdrop_url,
              video_url, video_kind, featured, published, country, release_date, director, cast_names, writers,
              rating, imdb_id, tmdb_id, trailer_url, subtitle_languages, audio_languages, quality, tags) on public.movies to authenticated;
grant delete on public.movies to authenticated;

grant select, insert, delete on public.movie_likes to authenticated;
grant select, delete on public.movie_comments to authenticated;
grant insert (movie_id, user_id, parent_id, body) on public.movie_comments to authenticated;
grant select, insert, update, delete on public.my_list to authenticated;
grant select, insert, update, delete on public.watch_progress to authenticated;
grant select, insert, update, delete on public.episode_watch_progress to authenticated;

grant select on public.ads to authenticated;
grant insert (title, kind, media_url, link_url, duration_seconds, skip_after_seconds, active) on public.ads to authenticated;
grant update (title, kind, media_url, link_url, duration_seconds, skip_after_seconds, active) on public.ads to authenticated;
grant delete on public.ads to authenticated;
grant select on public.ad_views to authenticated;
grant insert (ad_id, user_id, movie_id, completed) on public.ad_views to authenticated;

grant select on public.posts to authenticated;
grant insert (user_id, kind, caption, media_url, poster_url) on public.posts to authenticated;
grant update (caption) on public.posts to authenticated;
grant delete on public.posts to authenticated;

grant select, insert, delete on public.post_likes, public.post_saves, public.comment_likes to authenticated;
grant select, delete on public.post_comments to authenticated;
grant insert (post_id, user_id, parent_id, body) on public.post_comments to authenticated;
grant select, insert, delete on public.follows to authenticated;

grant select, delete on public.notifications to authenticated;
grant update (read) on public.notifications to authenticated;
grant select on public.reports to authenticated;
grant update (status,handled_by,updated_at) on public.reports to authenticated;
grant insert (reporter_id, target_type, target_id, reason, category, details, metadata) on public.reports to authenticated;

grant select on public.conversations to authenticated;
grant select on public.conversation_members to authenticated;
grant update (last_read_at, muted) on public.conversation_members to authenticated;
grant select on public.series, public.seasons, public.episodes to authenticated;
grant insert, update, delete on public.series, public.seasons, public.episodes to authenticated;
grant select, insert, delete on public.saved_messages to authenticated;
grant select, insert, delete on public.message_reactions to authenticated;
grant select, update on public.user_devices to authenticated;
grant select on public.messages to authenticated;
grant insert (conversation_id, sender_id, body, media_url, media_type, media_name, reply_to) on public.messages to authenticated;
grant update (body, edited_at, deleted_at) on public.messages to authenticated;


-- =====================================================================
-- 11) STORAGE BUCKETS + POLICIES
--     avatars/posts/chat: users write only inside their own folder <user-id>/
--     movies: only publishers / owner
--     NOTE: the max upload size is also limited by the global limit in
--     Supabase -> Storage -> Settings. Raise it there for big movie files.
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('avatars', 'avatars', true, 5242880,
     array['image/jpeg','image/png','image/webp','image/gif']),
  ('posts',   'posts',   true, 104857600,
     array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime']),
  ('chat',    'chat',    true, 26214400,
     array['image/jpeg','image/png','image/webp','image/gif','audio/webm','audio/ogg','audio/mpeg','audio/mp4']),
  ('movies',  'movies',  true, 5368709120,
     array['image/jpeg','image/png','image/webp','video/mp4','video/webm','video/quicktime','video/x-matroska'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "auxy_own_folder_insert" on storage.objects;
drop policy if exists "auxy_own_folder_update" on storage.objects;
drop policy if exists "auxy_own_folder_delete" on storage.objects;
drop policy if exists "auxy_movies_insert" on storage.objects;
drop policy if exists "auxy_movies_update" on storage.objects;
drop policy if exists "auxy_movies_delete" on storage.objects;

create policy "auxy_own_folder_insert" on storage.objects for insert to authenticated
  with check (bucket_id in ('avatars','posts','chat')
              and (storage.foldername(name))[1] = (select auth.uid())::text and not public.is_banned());
create policy "auxy_own_folder_update" on storage.objects for update to authenticated
  using (bucket_id in ('avatars','posts','chat') and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "auxy_own_folder_delete" on storage.objects for delete to authenticated
  using (bucket_id in ('avatars','posts','chat')
         and ((storage.foldername(name))[1] = (select auth.uid())::text or public.is_staff()));

create policy "auxy_movies_insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'movies' and public.is_publisher());
create policy "auxy_movies_update" on storage.objects for update to authenticated
  using (bucket_id = 'movies' and public.is_publisher());
create policy "auxy_movies_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'movies' and public.is_publisher());


-- =====================================================================
-- 12) REALTIME (live chat + live notifications)
-- =====================================================================
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime'
                 and schemaname = 'public' and tablename = 'messages') then
    alter publication supabase_realtime add table public.messages;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime'
                 and schemaname = 'public' and tablename = 'notifications') then
    alter publication supabase_realtime add table public.notifications;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime'
                 and schemaname = 'public' and tablename = 'message_reactions') then
    alter publication supabase_realtime add table public.message_reactions;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'conversation_members') then
    alter publication supabase_realtime add table public.conversation_members;
  end if;
end $$;


-- =====================================================================
-- 13) FINAL BACKFILL / GLOBAL HANDLE SYNC
-- =====================================================================

-- Existing Auth accounts get their local rows and password state synced.
insert into public.user_private(user_id,email,recovery_email,password_set)
select id,email,email,nullif(coalesce(encrypted_password,''),'') is not null
from auth.users
on conflict(user_id) do update set
  email=coalesce(public.user_private.email,excluded.email),
  recovery_email=coalesce(public.user_private.recovery_email,excluded.recovery_email),
  password_set=public.user_private.password_set or excluded.password_set;

insert into public.profiles(id,display_name,avatar_url)
select id,coalesce(raw_user_meta_data->>'display_name',raw_user_meta_data->>'full_name',raw_user_meta_data->>'name'),
       coalesce(raw_user_meta_data->>'avatar_url',raw_user_meta_data->>'picture')
from auth.users
on conflict(id) do nothing;

-- Copy existing public usernames into the global handle namespace without touching any
-- already-owned group/channel handle.
insert into public.handles(handle,owner_type,owner_id)
select lower(username),'user',id
from public.profiles
where username is not null
  and public._username_format_error(lower(username)) is null
on conflict(handle) do nothing;

update public.profiles set role='owner' where lower(username) = any(array['ali','support','auxy']);

-- Any old local recovery address is kept; when it was empty, the Auth email is used.
update public.user_private up
set recovery_email=case when au.email like '%@accounts.auxy.invalid' then up.recovery_email else coalesce(up.recovery_email,au.email) end,
    email=coalesce(up.email,au.email),
    updated_at=now()
from auth.users au
where au.id=up.user_id;

-- Fixed Auxy administrator usernames. These accounts always retain owner/admin access.
update public.profiles
set role='owner', updated_at=now()
where lower(username)=any(array['ali','support','auxy']);


create or replace function public.touch_seen() returns void
language sql security definer set search_path='' as $$
  update public.profiles set last_seen_at=now() where id=auth.uid();
$$;

create or replace function public.record_login(p_user uuid) returns void
language plpgsql security definer set search_path='' as $$
begin
  if auth.uid() is null or auth.uid()<>p_user then return; end if;
  update public.profiles set last_login_at=now(),last_seen_at=now() where id=p_user;
end $$;


-- =====================================================================
-- FINAL AUTH / ADMIN / SETTINGS OVERRIDES
-- =====================================================================
create or replace function public.login_postprocess(p_user uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare cid uuid;
           em text;
begin
  if p_user is null or not exists(select 1 from auth.users where id=p_user) then
    return jsonb_build_object('ok',false,'code','user');
  end if;
  update public.profiles set last_login_at=now(),last_seen_at=now(),updated_at=now() where id=p_user;
  select id into cid from public.conversations where system_key='welcome:'||p_user::text limit 1;
  if cid is null then
    insert into public.conversations(kind,title,avatar_url,system_key,created_by,is_public,message_limit)
    values('system','Auxy','/auxy-black.png','welcome:'||p_user::text,null,false,4000) returning id into cid;
  end if;
  insert into public.conversation_members(conversation_id,user_id,role,status,permissions)
  values(cid,p_user,'member','active','{"send_messages":false,"view_members":false}'::jsonb)
  on conflict(conversation_id,user_id) do update set status='active';
  insert into public.messages(conversation_id,sender_id,body,media_type)
  select cid,null,case when exists(select 1 from public.messages where conversation_id=cid)
      then 'ورود جدید به حساب Auxy ثبت شد. اگر این ورود توسط تو نبوده، از تنظیمات > امنیت و دستگاه‌ها نشست‌های ناشناس را خاتمه بده.'
      else 'به Auxy خوش آمدی. اینجا پیام‌های رسمی سیستم، امنیت حساب و اعلان‌های مهم برایت ارسال می‌شود.' end,'none';
  return jsonb_build_object('ok',true,'conversation_id',cid);
end $$;

create or replace function public.provision_user_after_signup(p_user_id uuid,p_username text,p_display_name text,p_recovery_email text default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare u text:=lower(regexp_replace(trim(coalesce(p_username,'')),'^@+','')); er text; chk jsonb;
begin
  if p_user_id is null then return jsonb_build_object('ok',false,'code','user'); end if;
  er:=public._username_format_error(u);
  if er is not null or public._username_reserved(u) then return jsonb_build_object('ok',false,'code','invalid_username'); end if;
  if exists(select 1 from public.profiles where lower(username)=u and id<>p_user_id)
     or exists(select 1 from public.handles where handle=u) then return jsonb_build_object('ok',false,'code','username_taken'); end if;
  update public.profiles set username=u,display_name=coalesce(nullif(btrim(p_display_name),''),display_name),role=case when u=any(array['ali','support','auxy']) then 'owner' else role end,updated_at=now() where id=p_user_id;
  if not found then return jsonb_build_object('ok',false,'code','profile'); end if;
  insert into public.handles(handle,owner_type,owner_id) values(u,'user',p_user_id);
  update public.user_private set recovery_email=nullif(lower(trim(coalesce(p_recovery_email,''))),''),password_set=true,onboarded=true,updated_at=now() where user_id=p_user_id;
  return jsonb_build_object('ok',true);
exception when unique_violation then return jsonb_build_object('ok',false,'code','username_taken');
end $$;

create or replace function public.resolve_recovery_target(p_username text,p_email text) returns table(email text)
language sql security definer set search_path='' as $$
  select au.email
    from public.profiles p join public.user_private up on up.user_id=p.id join auth.users au on au.id=p.id
   where lower(p.username)=lower(regexp_replace(trim(coalesce(p_username,'')),'^@+',''))
     and up.recovery_email is not null
     and lower(up.recovery_email)=lower(trim(coalesce(p_email,'')))
   limit 1
$$;

create or replace function public.admin_user_detail(p_user uuid) returns table(
  id uuid,username text,display_name text,avatar_url text,bio text,role text,is_banned boolean,ban_reason text,
  email text,recovery_email text,password_set boolean,onboarded boolean,created_at timestamptz,last_login_at timestamptz,last_seen_at timestamptz,
  followers_count int,following_count int,posts_count int,message_count bigint,post_count bigint,device_count bigint
)
language plpgsql security definer set search_path='' as $$
begin
  if not public.is_owner() then raise exception 'not_allowed'; end if;
  return query select p.id,p.username,p.display_name,p.avatar_url,p.bio,p.role,p.is_banned,p.ban_reason,
      au.email,up.recovery_email,up.password_set,up.onboarded,p.created_at,p.last_login_at,p.last_seen_at,
      p.followers_count,p.following_count,p.posts_count,
      (select count(*) from public.messages m where m.sender_id=p.id),
      (select count(*) from public.posts x where x.user_id=p.id),
      (select count(*) from public.user_devices d where d.user_id=p.id and d.revoked_at is null)
    from public.profiles p join auth.users au on au.id=p.id left join public.user_private up on up.user_id=p.id where p.id=p_user;
end $$;

create or replace function public.admin_report_detail(p_report uuid) returns table(
  report_id uuid,reporter_id uuid,reporter_username text,target_type text,target_id uuid,category text,reason text,details text,metadata jsonb,status text,created_at timestamptz,handled_by uuid,navigation_path text
)
language plpgsql security definer set search_path='' as $$
declare r public.reports%rowtype; n text; nav text;
begin
  if not public.is_staff() then raise exception 'not_allowed'; end if;
  select * into r from public.reports where id=p_report; if not found then return; end if;
  select username into n from public.profiles where id=r.reporter_id;
  nav:=case r.target_type
    when 'message' then coalesce((select '/chat/'||conversation_id::text||'?msg='||r.target_id::text from public.messages where id=r.target_id),'/')
    when 'post' then '/scroll/'||r.target_id::text
    when 'user' then coalesce('/u/'||(select username from public.profiles where id=r.target_id),'')
    when 'movie' then '/movie/'||r.target_id::text
    when 'series' then '/series/'||r.target_id::text
    when 'episode' then '/episode/'||r.target_id::text
    when 'group' then '/chat/'||r.target_id::text
    when 'channel' then '/chat/'||r.target_id::text
    when 'post_comment' then coalesce('/scroll/'||(select post_id::text from public.post_comments where id=r.target_id),'/')
    when 'movie_comment' then coalesce('/movie/'||(select movie_id::text from public.movie_comments where id=r.target_id),'/')
    else '/'
  end;
  return query select r.id,r.reporter_id,n,r.target_type,r.target_id,r.category,r.reason,r.details,r.metadata,r.status,r.created_at,r.handled_by,nav;
end $$;

create or replace function public.admin_revoke_user_devices(p_user uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare n int;
begin
  if not public.is_owner() then raise exception 'not_allowed'; end if;
  update public.user_devices set revoked_at=now() where user_id=p_user and revoked_at is null;
  get diagnostics n=row_count;
  return jsonb_build_object('ok',true,'count',n);
end $$;

create or replace function public.admin_set_site_setting(p_key text,p_value jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
  if not public.is_owner() then raise exception 'not_allowed'; end if;
  if p_key not in ('vast_tag_url','player','site') then raise exception 'invalid_key'; end if;
  insert into public.site_settings(key,value,updated_by) values(p_key,coalesce(p_value,'{}'::jsonb),auth.uid()) on conflict(key) do update set value=excluded.value,updated_by=excluded.updated_by,updated_at=now();
  return jsonb_build_object('ok',true);
end $$;

-- Lock public aliases so no future registration can steal them. Existing accounts keep access.
insert into public.reserved_usernames(username,allowed_email,role) values
 ('ali','ali@accounts.auxy.invalid','owner'),('support','support@accounts.auxy.invalid','owner'),('auxy','auxy@accounts.auxy.invalid','owner')
on conflict(username) do nothing;

-- public handle ownership is global across users/groups/channels.
create unique index if not exists handles_global_key on public.handles(lower(handle));

-- Episode progress and updated_at triggers.
drop trigger if exists episodes_set_updated_at on public.episodes;
create trigger episodes_set_updated_at before update on public.episodes for each row execute function public.set_updated_at();
drop trigger if exists series_set_updated_at on public.series;
create trigger series_set_updated_at before update on public.series for each row execute function public.set_updated_at();

-- Helpful composite indexes.
create index if not exists movies_published_content_idx on public.movies(published,content_type,created_at desc);
create index if not exists reports_open_idx on public.reports(status,created_at desc);
create index if not exists user_devices_active_idx on public.user_devices(user_id,revoked_at,last_seen_at desc);


-- =====================================================================
-- 10) FUNCTION PRIVILEGES (after ALL functions are created)
-- =====================================================================
revoke execute on all functions in schema public from public, anon, authenticated;

-- Policy helpers
grant execute on function public.app_role(), public.is_owner(), public.is_publisher(), public.is_staff(),
                           public.is_banned(), public.is_conv_member(uuid) to authenticated;

-- Login/registration preflight: these must work before a session exists.
grant execute on function public.check_username(text), public.resolve_username_login(text) to anon, authenticated;

-- Authenticated application RPCs
grant execute on function
  public.bootstrap_me(), public.ensure_profile(), public.claim_username(text), public.sync_auth_password(), public.finish_onboarding(),
  public.update_recovery_email(text), public.change_username_native(text), public.delete_my_account_native(),
  public.set_app_password(text), public.verify_app_password(text), public.change_app_password(text, text),
  public.change_username(text, text), public.update_profile(text, text, text),
  public.increment_movie_view(uuid), public.increment_post_view(uuid), public.toggle_post_like(uuid), public.toggle_movie_like(uuid), public.toggle_comment_like(uuid), public.touch_seen(), public.record_login(uuid), public.start_direct_chat(uuid), public.create_group(text, uuid[]),
  public.add_group_members(uuid, uuid[]), public.create_channel(text, text, text, boolean), public.search_channels(text, int),
  public.join_channel(uuid), public.join_channel_invite(text), public.set_conversation_handle(uuid, text), public.leave_conversation(uuid), public.mark_read(uuid), public.my_conversations(),
  public.admin_stats(), public.admin_list_users(text, int, int), public.admin_set_role(uuid, text),
  public.admin_set_ban(uuid, boolean, text), public.admin_reset_password(uuid), public.admin_delete_user(uuid),
  public.is_conv_manager(uuid), public.conv_can_send_message(uuid), public.conv_can_manage_members(uuid), public.conv_can_manage_admins(uuid), public.conv_can_view_members(uuid), public.conv_can_invite_members(uuid), public.conv_can_manage_theme(uuid), public.conv_can_edit_info(uuid), public.conv_can_pin_messages(uuid),
  public.get_conversation_members(uuid), public.set_member_role(uuid,uuid,text,jsonb), public.set_member_permissions(uuid,uuid,jsonb), public.add_channel_admin(uuid,uuid,jsonb),
  public.create_group_v2(text,text,text,boolean,uuid[]), public.join_group_public(uuid), public.join_group_invite(text), public.resolve_public_handle(text), public.set_conversation_theme(uuid,jsonb),
  public.save_message(uuid), public.unsave_message(uuid), public.list_saved_messages(int), public.toggle_message_reaction(uuid,text), public.ensure_auxy_welcome(),
  public.register_device(text,text,text), public.list_my_devices(), public.revoke_device(uuid), public.is_current_device_revoked(text),
  public.create_series(text,text,int,text[],text,text,text,boolean,boolean), public.create_season(uuid,int,text), public.create_episode(uuid,int,text,text,int,text,text,text,boolean), public.submit_report(text,uuid,text,text,text)
  to authenticated;

-- Service-role-only backend functions
grant execute on function public.provision_user_after_signup(uuid,text,text,text), public.resolve_recovery_target(text,text), public.login_postprocess(uuid) to service_role;

-- Staff/owner detail functions are gated internally; callable only through authenticated RPC.
grant execute on function public.admin_user_detail(uuid), public.admin_report_detail(uuid), public.admin_revoke_user_devices(uuid), public.admin_set_site_setting(text,jsonb) to authenticated;

commit;
