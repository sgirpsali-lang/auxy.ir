/* Auxy support: real ticketing + live staff presence */
(function(){
  'use strict';
  var A=window.AUXY,C=A.core,sb=A.client,esc=C.esc,$=C.$;
  A.mod.support={open:open};
  async function open(ctx){
    var el=ctx.el, ticketId=ctx.params.id||null;
    var staff=(await sb.from('profiles').select('id,username,display_name,avatar_url,role').in('role',['owner','moderator']).limit(20)).data||[];
    staff.forEach(function(u){C.users[u.id]=u;});
    if(ticketId)return thread(ticketId);
    var r=await sb.from('support_tickets').select('*').eq('user_id',C.uid).order('updated_at',{ascending:false});
    var rows=r.data||[];
    el.innerHTML='<div class="page-pad"><div class="studio-h"><h1 class="page-h">پشتیبانی</h1><button class="btn primary" id="newTicket">تیکت جدید</button></div><div class="support-agents"><b>پشتیبان‌ها</b>'+staff.map(function(u){return '<span class="agent">'+C.avatar(u,30)+'<span>@'+esc(u.username||'staff')+'</span><i class="'+(C.online.has(u.id)?'online':'offline')+'"></i></span>';}).join('')+'</div><div class="support-list">'+(rows.length?rows.map(card).join(''):C.empty('info','هنوز تیکتی نداری','اگر مشکلی داری همین‌جا پیام بده.'))+'</div></div>';
    $('#newTicket',el).addEventListener('click',function(){
      var m=C.modal({title:'تیکت جدید',body:'<label class="field"><span>موضوع</span><input class="input" id="st" maxlength="160"></label><label class="field"><span>پیام</span><textarea class="input" id="sm" rows="5"></textarea></label>',actions:[{label:'انصراف',onClick:function(a){a.close();}},{label:'ارسال',kind:'primary',onClick:async function(a){var subject=$('#st',m.el).value.trim(),body=$('#sm',m.el).value.trim();if(!subject||!body)return C.toast('موضوع و پیام را وارد کن','bad');var t=await sb.from('support_tickets').insert({user_id:C.uid,subject:subject}).select().single();if(t.error)return C.toast(C.err(t.error),'bad');var q=await sb.from('support_messages').insert({ticket_id:t.data.id,sender_id:C.uid,body:body});if(q.error)return C.toast(C.err(q.error),'bad');a.close();C.go('/support/'+t.data.id);}}]});
    });
  }
  function card(t){return '<a class="support-card" href="#/support/'+t.id+'"><div><b>'+esc(t.subject)+'</b><small>'+esc(t.priority)+' · '+esc(t.status)+'</small></div><time>'+C.clock(t.updated_at)+'</time></a>';}
  async function thread(id){
    var t=(await sb.from('support_tickets').select('*').eq('id',id).single()).data;
    if(!t||(!C.isStaff()&&t.user_id!==C.uid)){C.go('/support');return;}
    var rows=(await sb.from('support_messages').select('*').eq('ticket_id',id).order('created_at')).data||[];
    await C.hydrate(rows,'sender_id');
    var el=arguments.callee.ctxEl||null;
    // ctx.el is not available through arguments in async recursion; store via wrapper below.
  }
  // Replace thread with a closure-friendly implementation.
  open=async function(ctx){
    var el=ctx.el,id=ctx.params.id||null;
    if(!id){
      var staff=(await sb.from('profiles').select('id,username,display_name,avatar_url,role').in('role',['owner','moderator']).limit(20)).data||[];staff.forEach(function(u){C.users[u.id]=u;});
      var r=await sb.from('support_tickets').select('*').eq('user_id',C.uid).order('updated_at',{ascending:false});var rows=r.data||[];
      el.innerHTML='<div class="page-pad"><div class="studio-h"><h1 class="page-h">پشتیبانی</h1><button class="btn primary" id="newTicket">تیکت جدید</button></div><div class="support-agents"><b>پشتیبان‌ها</b>'+staff.map(function(u){return '<span class="agent">'+C.avatar(u,30)+'<span>@'+esc(u.username||'staff')+'</span><i class="'+(C.online.has(u.id)?'online':'offline')+'"></i></span>';}).join('')+'</div><div class="support-list">'+(rows.length?rows.map(card).join(''):C.empty('info','هنوز تیکتی نداری','اگر مشکلی داری همین‌جا پیام بده.'))+'</div></div>';
      $('#newTicket',el).addEventListener('click',function(){var m=C.modal({title:'تیکت جدید',body:'<label class="field"><span>موضوع</span><input class="input" id="st" maxlength="160"></label><label class="field"><span>پیام</span><textarea class="input" id="sm" rows="5"></textarea></label>',actions:[{label:'انصراف',onClick:function(a){a.close();}},{label:'ارسال',kind:'primary',onClick:async function(a){var subject=$('#st',m.el).value.trim(),body=$('#sm',m.el).value.trim();if(!subject||!body)return C.toast('موضوع و پیام را وارد کن','bad');var t=await sb.from('support_tickets').insert({user_id:C.uid,subject:subject}).select().single();if(t.error)return C.toast(C.err(t.error),'bad');var q=await sb.from('support_messages').insert({ticket_id:t.data.id,sender_id:C.uid,body:body});if(q.error)return C.toast(C.err(q.error),'bad');a.close();C.go('/support/'+t.data.id);}}]});});
      return;
    }
    var t=(await sb.from('support_tickets').select('*').eq('id',id).single()).data;if(!t||(!C.isStaff()&&t.user_id!==C.uid)){C.go('/support');return;}
    var rows=(await sb.from('support_messages').select('*').eq('ticket_id',id).order('created_at')).data||[];await C.hydrate(rows,'sender_id');
    el.innerHTML='<div class="page-pad"><a class="btn ghost" href="#/support">‹ پشتیبانی</a><h1 class="page-h">'+esc(t.subject)+'</h1><div class="support-thread" id="stMessages">'+rows.map(function(m){var u=C.user(m.sender_id);return '<div class="support-msg '+(m.sender_id===C.uid?'mine':'')+'">'+C.avatar(u,28)+'<div><b>@'+esc(u.username||'user')+'</b><p>'+esc(m.body||'')+'</p><time>'+C.clock(m.created_at)+'</time></div></div>';}).join('')+'</div><form class="support-compose"><textarea class="input" id="spBody" rows="2" placeholder="پیامت…"></textarea><button class="btn primary">ارسال</button></form>'+(C.isStaff()?'<button class="btn glass" id="closeTicket">بستن تیکت</button>':'')+'</div>';
    $('.support-compose',el).addEventListener('submit',async function(e){e.preventDefault();var body=$('#spBody',el).value.trim();if(!body)return;var r=await sb.from('support_messages').insert({ticket_id:id,sender_id:C.uid,body:body});if(r.error)return C.toast(C.err(r.error),'bad');$('#spBody',el).value='';open(ctx);});
    var cb=$('#closeTicket',el);if(cb)cb.addEventListener('click',async function(){var r=await sb.from('support_tickets').update({status:'closed',updated_at:new Date().toISOString()}).eq('id',id);if(r.error)return C.toast(C.err(r.error),'bad');open(ctx);});
  };
})();
