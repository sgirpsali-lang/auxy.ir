/* Auxy web: chat (direct + groups, realtime, typing, read receipts, images, replies, edit/delete) */
(function () {
  'use strict';
  var A = window.AUXY, C = A.core, sb = A.client, esc = C.esc, $ = C.$;
  A.mod.chat = { open: open };
  var EMOJI = ['😀', '😂', '😍', '🥰', '😎', '🤔', '😢', '😭', '😡', '👍', '👎', '🙏', '👏', '🔥', '💯', '❤️', '💔', '🎉', '🎬', '🍿', '⭐', '✨', '😴', '🤝', '🙌', '😅', '😉', '😊', '🤩', '🥳', '😱', '🤯'];

  function name(c) { if(c.kind==='group') return c.title || 'گروه'; if(c.kind==='channel') return c.title || 'کانال'; if(c.kind==='system') return 'Auxy'; var u=C.user(c.other_id); return (u && (u.display_name || u.username)) || c.other_display_name || c.other_username || 'کاربر'; }
  function av(c, s) { if(c.kind==='system') return C.avatar({system:true},s); return (c.kind==='group'||c.kind==='channel') ? C.avatar({ username: c.title || (c.kind==='channel'?'C':'G'), avatar_url: c.avatar_url }, s) : C.avatar(C.user(c.other_id), s); }
  function linkify(t) { return esc(t).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer nofollow">$1</a>').replace(/\n/g, '<br>'); }
  function preview(c) {
    if (c.last_at == null && !c.last_body && !c.last_media) return 'گفتگو را شروع کن';
    var who = c.last_sender === C.uid ? 'شما: ' : '';
    if (c.last_media && !c.last_body) return who + (c.last_media_type === 'audio' || c.last_media_type === 'voice' ? 'پیام صوتی' : 'رسانه');
    return who + (c.last_body === '' ? 'این پیام حذف شد' : (c.last_body || ''));
  }
  async function findUsers(q) {
    q = q.replace(/[%_,()\\]/g, ' ').trim(); if (q.length < 2) return [];
    var r = await sb.from('profiles').select('id,username,display_name,avatar_url,role').or('username.ilike.' + q + '%,display_name.ilike.%' + q + '%').neq('id', C.uid).limit(10);
    (r.data || []).forEach(function (u) { C.users[u.id] = u; }); return r.data || [];
  }

  async function open(ctx) {
    var el = ctx.el, targetMsg = ctx.query && ctx.query.get('msg') ? ctx.query.get('msg') : null, st = { active: null, msgs: [], members: [], more: false, reply: null, edit: null, typing: 0, tch: null, q: '', dead: false };
    el.innerHTML = '<div class="chat"><aside class="chat-list"><div class="chat-list-h"><h2>پیام‌ها</h2><div><button class="icon-btn" data-a="group" aria-label="گروه جدید">' + C.icon('users', { size: 21 }) + '</button><button class="icon-btn" data-a="channel" aria-label="کانال جدید">' + C.icon('megaphone', { size: 21 }) + '</button><button class="icon-btn" data-a="new" aria-label="چت جدید">' + C.icon('edit', { size: 21 }) + '</button></div></div>' +
      '<div class="chat-search">' + C.icon('search', { size: 17 }) + '<input type="search" placeholder="جستجو در گفتگوها" aria-label="جستجو در گفتگوها"></div><div class="chat-items"></div></aside><section class="chat-thread"></section></div>';
    var root = $('.chat', el), items = $('.chat-items', el), thread = $('.chat-thread', el);

    await C.refreshBadges();
    await C.hydrate(C.convs.filter(function (c) { return c.other_id; }), 'other_id');
    for(var ci=0;ci<C.convs.length;ci++){var cc=C.convs[ci];if(cc.kind==='direct'&&cc.other_id&&!C.user(cc.other_id)){try{var ur=await C.withTimeout(sb.from('profiles').select('id,username,display_name,avatar_url,role,is_banned').eq('id',cc.other_id).maybeSingle(),7000,'کاربر');if(ur.data)C.users[cc.other_id]=ur.data;}catch(e){}}}

    /* ----- list ----- */
    function renderList() {
      var l = C.convs.filter(function (c) { return !st.q || name(c).toLowerCase().indexOf(st.q) > -1; });
      items.innerHTML = l.length ? l.map(function (c) {
        var on = c.kind === 'direct' && C.online.has(c.other_id);
        return '<a class="citem' + (c.conv_id === st.active ? ' on' : '') + '" href="#/chat/' + c.conv_id + '"><span class="cav">' + av(c, 48) + (on ? '<i class="dot"></i>' : '') + '</span>' +
          '<span class="cbody"><span class="crow"><b>' + esc(name(c)) + '</b><time>' + (c.last_at ? C.clock(c.last_at) : '') + '</time></span>' +
          '<span class="crow"><span class="cprev">' + esc(preview(c)) + '</span>' + (c.unread ? '<em class="badge">' + C.compact(c.unread) + '</em>' : '') + '</span></span></a>';
      }).join('') : '<p class="chat-none">' + (st.q ? 'چیزی پیدا نشد' : 'هنوز گفتگویی نداری. با دکمه‌ی بالا یک چت شروع کن.') + '</p>';
    }
    $('.chat-search input', el).addEventListener('input', function (e) { st.q = e.target.value.trim().toLowerCase(); renderList(); });

    /* ----- new chat / group ----- */
    function picker(o) {
      var chosen = [], m = C.modal({
        title: o.title, body: (o.group ? '<label class="field"><span>نام گروه</span><input class="input" id="gt" maxlength="60" placeholder="مثلاً دوستان فیلم"></label>' : '') +
          '<label class="field"><span>' + (o.group ? 'افزودن اعضا' : 'جستجوی کاربر') + '</span><input class="input" id="us" placeholder="نام کاربری یا نام" autocomplete="off"></label><div class="chips" id="ch"></div><div class="ulist" id="ur"></div>',
        actions: o.group ? [{ label: 'انصراف', onClick: function (a) { a.close(); } }, { label: 'ساخت گروه', kind: 'primary', onClick: function (a, b) { o.done(m, chosen, $('#gt', m.el).value.trim(), b); } }] : []
      });
      var ur = $('#ur', m.el), ch = $('#ch', m.el), inp = $('#us', m.el);
      function chips() { ch.innerHTML = chosen.map(function (u) { return '<button class="chip on" data-r="' + u.id + '">@' + esc(u.username) + ' ' + C.icon('x', { size: 12 }) + '</button>'; }).join(''); }
      inp.addEventListener('input', C.debounce(async function () {
        var us = await findUsers(inp.value);
        ur.innerHTML = us.length ? us.map(function (u) { return '<button class="uitem" data-u="' + u.id + '">' + C.avatar(u, 40) + '<span><b>' + esc(C.name(u)) + '</b><small>@' + esc(u.username) + '</small></span></button>'; }).join('') : (inp.value.trim().length >= 2 ? '<p class="chat-none">کاربری پیدا نشد</p>' : '');
      }, 300));
      m.el.addEventListener('click', function (e) {
        var b = e.target.closest('[data-u]'), r = e.target.closest('[data-r]');
        if (b) { var id = b.getAttribute('data-u'); if (!o.group) return o.pick(m, id); if (!chosen.some(function (x) { return x.id === id; })) { chosen.push(C.users[id]); chips(); } }
        if (r) { chosen = chosen.filter(function (x) { return x.id !== r.getAttribute('data-r'); }); chips(); }
      });
    }
    async function newDirect(m, id) {
      var r = await sb.rpc('start_direct_chat', { p_user: id }); if (r.error) return C.toast(C.err(r.error), 'bad');
      m.close(); await C.refreshBadges(); C.go('/chat/' + r.data);
    }
    root.addEventListener('click', function (e) {
      var a = e.target.closest('[data-a]'); if (!a) return; a = a.getAttribute('data-a');
      if (a === 'new') picker({ title: 'چت جدید', pick: newDirect });
      else if (a === 'channel') createChannel();
      else if (a === 'group') picker({ title: 'گروه جدید', group: true, done: async function (m, chosen, title, btn) {
        if (!title) return C.toast('برای گروه یک نام بنویس', 'bad');
        btn.disabled = true; var r = await sb.rpc('create_group', { p_title: title, p_members: chosen.map(function (u) { return u.id; }) });
        if (r.error) { btn.disabled = false; return C.toast(C.err(r.error), 'bad'); }
        m.close(); await C.refreshBadges(); C.go('/chat/' + r.data);
      } });
    });

    async function showSaved() {
      var r=await sb.from('saved_messages').select('*').order('created_at',{ascending:false}).limit(100);
      if(r.error)return C.toast(C.err(r.error),'bad');
      var rows=r.data||[];
      var body=rows.length?rows.map(function(x){return '<div class="saved-row">'+(x.media_type==='audio'?'<audio controls src="'+esc(x.media_url||'')+'"></audio>':'')+(x.body?'<p dir="auto">'+linkify(x.body)+'</p>':'')+'<time>'+C.clock(x.created_at)+'</time></div>';}).join(''):'<p class="chat-none">هنوز پیامی ذخیره نکرده‌ای.</p>';
      C.modal({title:'پیام‌های ذخیره‌شده',wide:true,body:'<div class="saved-list">'+body+'</div>',actions:[{label:'بستن',onClick:function(a){a.close();}}]});
    }

    async function createChannel() {
      var m=C.modal({title:'ساخت کانال',body:'<label class="field"><span>نام کانال</span><input class="input" id="ct" maxlength="80"></label><label class="field"><span>آیدی عمومی (اختیاری)</span><div class="un-wrap"><b>@</b><input class="input ltr" id="cu" maxlength="32" placeholder="mychannel"></div></label><label class="field"><span>توضیح</span><textarea class="input" id="cd" maxlength="300"></textarea></label><label class="check"><input id="cp" type="checkbox" checked><span>کانال عمومی باشد</span></label><div class="form-err" id="ce" hidden></div>',actions:[{label:'انصراف',onClick:function(a){a.close();}},{label:'ساخت',kind:'primary',onClick:async function(a,b){var title=$('#ct',m.el).value.trim(),u=$('#cu',m.el).value.trim().toLowerCase(),d=$('#cd',m.el).value.trim(),pub=$('#cp',m.el).checked;if(!title)return C.toast('نام کانال را وارد کن','bad');b.disabled=true;var r=await sb.rpc('create_channel',{p_title:title,p_username:u||null,p_description:d||null,p_public:pub});if(r.error){b.disabled=false;$('#ce',m.el).textContent=C.err(r.error);$('#ce',m.el).hidden=false;return;}m.close();await C.refreshBadges();C.go('/chat/'+r.data);}}]});
    }

    /* ----- thread ----- */
    function conv() { return C.convs.filter(function (c) { return c.conv_id === st.active; })[0]; }
    function otherRead() { var o = st.members.filter(function (x) { return x.user_id !== C.uid; })[0]; return o ? new Date(o.last_read_at).getTime() : 0; }
    function status() {
      var c = conv(); if (!c) return '';
      if (st.typing > Date.now()) return '<span class="typing">در حال نوشتن…</span>';
      if (c.kind === 'group') return C.fa(c.member_count) + ' عضو';
      return C.online.has(c.other_id) ? '<span class="on-t">آنلاین</span>' : '';
    }
    function renderHead() { var c = conv(); if (!c) return; $('.th-name', thread).textContent = name(c); $('.th-sub', thread).innerHTML = status(); }
    function bubble(m, i) {
      var mine = m.sender_id === C.uid, prev = st.msgs[i - 1], u = C.user(m.sender_id), c = conv();
      var day = !prev || new Date(prev.created_at).toDateString() !== new Date(m.created_at).toDateString();
      var cont = prev && !day && prev.sender_id === m.sender_id && (new Date(m.created_at) - new Date(prev.created_at)) < 300000;
      var rep = m.reply_to ? st.msgs.filter(function (x) { return x.id === m.reply_to; })[0] : null;
      var del = !!m.deleted_at, read = mine && c && c.kind === 'direct' && otherRead() >= new Date(m.created_at).getTime();
      return (day ? '<div class="day"><span>' + C.dayLabel(m.created_at) + '</span></div>' : '') +
        '<div class="msg' + (mine ? ' mine' : '') + (cont ? ' cont' : '') + (m._tmp ? ' tmp' : '') + '" data-id="' + m.id + '">' +
        (!mine && c && c.kind === 'group' ? (cont ? '<span class="msg-av"></span>' : '<span class="msg-av">' + C.avatar(u, 30) + '</span>') : '') +
        '<div class="bub">' + (!mine && c && c.kind === 'group' && !cont ? '<b class="msg-name">' + esc(C.name(u)) + '</b>' : '') +
        (rep ? '<div class="quote"><b>' + esc(C.name(C.user(rep.sender_id))) + '</b><span>' + esc(rep.deleted_at ? 'پیام حذف شد' : (rep.body || 'تصویر')) + '</span></div>' : '') +
        (del ? '<p class="gone">این پیام حذف شد</p>' : ((m.message_type === 'voice' || m.media_type === 'audio') && m.media_url ? '<audio class="msg-audio" controls preload="metadata" src="' + esc(m.media_url) + '"></audio>' : (m.media_url ? '<img class="msg-img" src="' + esc(m.media_url) + '" alt="رسانه" loading="lazy">' : '')) + (m.body ? '<p dir="auto">' + linkify(m.body) + '</p>' : '')) +
        '<span class="meta">' + (m.edited_at && !del ? 'ویرایش‌شده · ' : '') + C.clock(m.created_at) + (mine ? C.icon(m._tmp ? 'clock' : (read ? 'checks' : 'check'), { size: 14, sw: 2.4 }) : '') + '</span>' +
        (!del && !m._tmp ? '<button class="msg-more icon-btn" data-a="m" aria-label="گزینه‌ها">' + C.icon('chevD', { size: 16 }) + '</button>' : '') + '</div></div>';
    }
    function renderMsgs(stick) {
      var box = $('.msgs', thread); if (!box) return;
      var near = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
      box.innerHTML = (st.more ? '<button class="btn ghost sm older" data-a="older">پیام‌های قدیمی‌تر</button>' : '') + st.msgs.map(bubble).join('') + (st.msgs.length ? '' : '<p class="chat-none">هنوز پیامی نیست. سلام کن!</p>');
      if (stick || near) box.scrollTop = box.scrollHeight;
    }
    function setBar() {
      var bar = $('.reply-bar', thread); if (!bar) return;
      var t = st.edit ? ['ویرایش پیام', st.edit.body] : st.reply ? ['پاسخ به ' + C.name(C.user(st.reply.sender_id)), st.reply.body || 'تصویر'] : null;
      bar.hidden = !t; if (t) bar.innerHTML = '<div><b>' + esc(t[0]) + '</b><span>' + esc(t[1] || '') + '</span></div><button class="icon-btn" data-a="cancel" aria-label="لغو">' + C.icon('x', { size: 18 }) + '</button>';
    }
    async function markRead() {
      var c = conv(); if (!c || !st.active) return;
      if (c.unread) { C.unread.chat = Math.max(0, C.unread.chat - c.unread); c.unread = 0; C.emit('badges'); renderList(); }
      sb.rpc('mark_read', { p_conv: st.active }).then(function () { }, function () { });
    }
    function typingChannel() {
      if (st.tch) sb.removeChannel(st.tch); if (st.readCh) sb.removeChannel(st.readCh);
      st.tch = sb.channel('typing:' + st.active);
      st.tch.on('broadcast', { event: 't' }, function (p) {
        if (p.payload && p.payload.u !== C.uid) { st.typing = Date.now() + 3500; renderHead(); setTimeout(renderHead, 3600); }
      }).subscribe();
    }
    async function openConv(id) {
      st.active = id; C.chatState.active = id; st.msgs = []; st.members = []; st.reply = null; st.edit = null; st.typing = 0;
      var c = conv();
      if (!c) { await C.refreshBadges(); c = conv(); }
      root.classList.toggle('thread-open', !!c); renderList();
      if (!c) { thread.innerHTML = C.empty('chat', 'این گفتگو پیدا نشد', '', '<a class="btn primary" href="#/chat">بازگشت</a>'); return; }
      var directUser = c.kind === 'direct' ? C.user(c.other_id) : null;
      thread.innerHTML = '<header class="th-h"><a class="icon-btn th-back" href="#/chat" aria-label="بازگشت">' + C.icon('chevR', { size: 24 }) + '</a>' +
        (directUser ? '<a class="th-profile" href="#/u/' + esc(directUser.username) + '">' + av(c, 42) + '</a>' : av(c,42)) +
        '<div class="th-t"><b class="th-name"></b><small class="th-sub"></small></div>' +
        (directUser ? '<a class="icon-btn" href="#/u/' + esc(directUser.username) + '" aria-label="پروفایل">' + C.icon('user', { size: 21 }) + '</a><button class="icon-btn" data-a="callAudio" aria-label="تماس صوتی">' + C.icon('phone', { size: 21 }) + '</button><button class="icon-btn" data-a="callVideo" aria-label="تماس تصویری">' + C.icon('video', { size: 21 }) + '</button>' : '') +
        (c.kind === 'group' ? '<button class="icon-btn" data-a="callAudio" aria-label="تماس گروهی">' + C.icon('phone', { size: 21 }) + '</button><button class="icon-btn" data-a="info" aria-label="اطلاعات گروه">' + C.icon('info', { size: 22 }) + '</button>' : '') +
        '<button class="icon-btn" data-a="savechat" aria-label="پیام‌های ذخیره‌شده">' + C.icon('bookmark', { size: 21 }) + '</button></header>' +
        '<div class="msgs" aria-live="polite"><span class="spin"></span></div><div class="reply-bar" hidden></div>' +
        '<form class="composer"><button type="button" class="icon-btn" data-a="emoji" aria-label="ایموجی">' + C.icon('smile', { size: 24 }) + '</button><button type="button" class="icon-btn" data-a="img" aria-label="ارسال تصویر">' + C.icon('image', { size: 24 }) + '</button><button type="button" class="icon-btn" data-a="voice" aria-label="پیام صوتی">' + C.icon('mic', { size: 24 }) + '</button>' +
        '<input type="file" accept="image/jpeg,image/png,image/webp,image/gif" hidden id="cf"><textarea rows="1" maxlength="4000" placeholder="پیام…" aria-label="پیام"></textarea><button class="btn primary send" type="submit" disabled aria-label="ارسال">' + C.icon('send', { size: 20 }) + '</button></form><div class="emoji" hidden></div>';
      renderHead();
      var r = await Promise.all([
        sb.from('messages').select('*').eq('conversation_id', id).order('created_at', { ascending: false }).limit(40),
        sb.from('conversation_members').select('user_id,role,last_read_at,status,permissions').eq('conversation_id', id).eq('status','active')
      ]);
      if (st.active !== id || st.dead) return;
      st.msgs = (r[0].data || []).reverse(); st.more = (r[0].data || []).length === 40; st.members = r[1].data || [];
      if(st.readCh) { try { sb.removeChannel(st.readCh); } catch(e){} }
      st.readCh=sb.channel('reads:'+id).on('postgres_changes',{event:'UPDATE',schema:'public',table:'conversation_members',filter:'conversation_id=eq.'+id},function(payload){var v=payload.new||{};for(var i=0;i<st.members.length;i++){if(st.members[i].user_id===v.user_id)st.members[i]=Object.assign(st.members[i],v)}renderMsgs(false)}).subscribe();
      await C.hydrate(st.msgs.concat(st.members), ['sender_id', 'user_id']);
      C.load('calls').then(function(){ if(A.calls&&A.calls.listen) A.calls.listen(id,st.members); });
      renderMsgs(true); if(targetMsg){setTimeout(function(){var q=$('.msg[data-id="'+targetMsg+'"]',thread);if(q){q.scrollIntoView({block:'center',behavior:'smooth'});q.classList.add('report-target');setTimeout(function(){q.classList.remove('report-target')},1800);}},150);} markRead(); typingChannel();
      var ta = $('textarea', thread), send = $('.send', thread);
      ta.addEventListener('input', function () {
        ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 140) + 'px'; send.disabled = !ta.value.trim();
        if (st.tch && Date.now() - (st._tt || 0) > 2500) { st._tt = Date.now(); st.tch.send({ type: 'broadcast', event: 't', payload: { u: C.uid } }); }
      });
      ta.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && C.settings.enterSend !== false && matchMedia('(hover:hover)').matches) { e.preventDefault(); $('.composer', thread).requestSubmit(); } });
      $('.composer', thread).addEventListener('submit', function (e) { e.preventDefault(); var t = ta.value.trim(); if (!t) return; ta.value = ''; ta.style.height = 'auto'; send.disabled = true; sendText(t); });
      if (matchMedia('(hover:hover)').matches) ta.focus();
    }
    function bump(m) { var c = conv(); if (c) { c.last_body = m.body; c.last_media = m.media_url; c.last_at = m.created_at; c.last_sender = m.sender_id; C.convs.sort(function (a, b) { return new Date(b.last_at || 0) - new Date(a.last_at || 0); }); } renderList(); }
    async function sendText(text, media) {
      if (st.edit) {
        var em = st.edit; st.edit = null; setBar();
        var r0 = await sb.from('messages').update({ body: text, edited_at: new Date().toISOString() }).eq('id', em.id);
        if (r0.error) return C.toast(C.err(r0.error), 'bad');
        em.body = text; em.edited_at = new Date().toISOString(); return renderMsgs();
      }
      var cid = st.active, tmp = { id: 'tmp-' + Date.now(), conversation_id: cid, sender_id: C.uid, body: text || null, media_url: media || null, reply_to: st.reply ? st.reply.id : null, created_at: new Date().toISOString(), _tmp: 1 };
      st.reply = null; var mt = st._mediaType || (media ? 'media' : 'text'); st._mediaType = null; tmp.message_type = mt; setBar(); st.msgs.push(tmp); renderMsgs(true);
      var r = await sb.from('messages').insert({ conversation_id: cid, sender_id: C.uid, body: tmp.body, media_url: tmp.media_url, media_type: tmp.media_type || 'none', reply_to: tmp.reply_to }).select('*').single();
      if (r.error) { st.msgs = st.msgs.filter(function (x) { return x !== tmp; }); renderMsgs(); return C.toast(C.err(r.error), 'bad'); }
      Object.assign(tmp, r.data); tmp._tmp = 0; renderMsgs(true); bump(tmp);
    }
    var recorder = null, recChunks = [], recStream = null;
    async function recordVoice() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) return C.toast('ضبط صدا در این مرورگر در دسترس نیست.', 'bad');
      if (recorder && recorder.state === 'recording') { recorder.stop(); return; }
      try {
        recStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        recorder = new MediaRecorder(recStream); recChunks = [];
        recorder.ondataavailable = function(e){ if(e.data.size) recChunks.push(e.data); };
        recorder.onstop = async function(){
          recStream.getTracks().forEach(function(t){t.stop();});
          var blob = new Blob(recChunks,{type:recorder.mimeType||'audio/webm'});
          var ext = (blob.type.indexOf('mp4')>-1?'m4a':'webm');
          var file = new File([blob],'voice-' + Date.now() + '.' + ext,{type:blob.type});
          try { C.toast('در حال ارسال ویس…'); var up=await C.upload('chat',file); st._mediaType='voice'; sendText('',up.url); }
          catch(er){C.toast(C.err(er),'bad');}
        };
        recorder.start(); C.toast('در حال ضبط… برای پایان دوباره بزن');
      } catch(e){ C.toast('اجازه‌ی میکروفون داده نشد.','bad'); }
    }

    thread.addEventListener('click', async function (e) {
      var b = e.target.closest('[data-a]'), img = e.target.closest('.msg-img');
      if (img) { var m = C.modal({ cls: 'lightbox', foot: false, title: '', body: '<img src="' + esc(img.src) + '" alt="" class="lb">' }); return; }
      if (!b) return; var a = b.getAttribute('data-a');
      if (a === 'emoji') { var ep = $('.emoji', thread); ep.hidden = !ep.hidden; if (!ep.innerHTML) ep.innerHTML = EMOJI.map(function (x) { return '<button type="button" data-e="' + x + '">' + x + '</button>'; }).join(''); }
      else if (a === 'img') $('#cf', thread).click();
      else if (a === 'cancel') { st.reply = null; st.edit = null; setBar(); }
      else if (a === 'older') {
        var first = st.msgs[0]; if (!first) return;
        var o = await sb.from('messages').select('*').eq('conversation_id', st.active).lt('created_at', first.created_at).order('created_at', { ascending: false }).limit(40);
        var rows = (o.data || []).reverse(); st.more = (o.data || []).length === 40; await C.hydrate(rows, 'sender_id'); st.msgs = rows.concat(st.msgs); renderMsgs(); 
      } else if (a === 'info') info();
      else if (a === 'm') {
        var id = b.closest('.msg').getAttribute('data-id'), msg = st.msgs.filter(function (x) { return x.id === id; })[0]; if (!msg) return;
        var mine = msg.sender_id === C.uid;
        var pop = C.pop(b, '<button data-x="save">' + C.icon('bookmark', { size: 18 }) + 'ذخیره</button><button data-x="rep">' + C.icon('reply', { size: 18 }) + 'پاسخ</button>' + (msg.body ? '<button data-x="cp">' + C.icon('copy', { size: 18 }) + 'کپی</button>' : '') + (mine && msg.body ? '<button data-x="ed">' + C.icon('edit', { size: 18 }) + 'ویرایش</button>' : '') + (mine ? '<button data-x="del">' + C.icon('trash', { size: 18 }) + 'حذف</button>' : ''));
        pop.addEventListener('click', async function (ev) {
          var x = ev.target.closest('[data-x]'); if (!x) return; x = x.getAttribute('data-x');
          if (x === 'save') { var sr=await sb.rpc('save_message',{p_message:msg.id}); if(sr.error||!sr.data||!sr.data.ok) C.toast(C.err(sr.error||sr.data),'bad'); else C.toast('پیام ذخیره شد'); }
          else if (x === 'rep') { st.reply = msg; st.edit = null; setBar(); $('textarea', thread).focus(); }
          else if (x === 'cp') C.copy(msg.body);
          else if (x === 'ed') { st.edit = msg; st.reply = null; setBar(); var ta = $('textarea', thread); ta.value = msg.body; ta.focus(); ta.dispatchEvent(new Event('input')); }
          else if (x === 'del' && await C.confirm({ title: 'حذف پیام', text: 'این پیام برای همه حذف شود؟', ok: 'حذف', danger: true })) {
            var r = await sb.from('messages').update({ deleted_at: new Date().toISOString(), body: '' }).eq('id', id);
            if (r.error) return C.toast(C.err(r.error), 'bad'); msg.deleted_at = new Date().toISOString(); msg.body = ''; renderMsgs();
          }
        });
      }
    });
    thread.addEventListener('click', function (e) { var b = e.target.closest('[data-e]'); if (b) { var ta = $('textarea', thread); ta.value += b.getAttribute('data-e'); ta.focus(); ta.dispatchEvent(new Event('input')); } });
    thread.addEventListener('change', async function (e) {
      if (e.target.id !== 'cf') return; var f = e.target.files[0]; e.target.value = ''; if (!f) return;
      try { C.toast('در حال ارسال تصویر…'); var up = await C.upload('chat', await C.compress(f, 1280, .82)); sendText('', up.url); } catch (er) { C.toast(C.err(er), 'bad'); }
    });
    thread.addEventListener('contextmenu', function (e) { var m = e.target.closest('.msg'); if (m && !e.target.closest('a')) { e.preventDefault(); var b = m.querySelector('[data-a=m]'); if (b) b.click(); } });

    async function info() {
      var c = conv(); if (!c) return;
      var me = st.members.filter(function (x) { return x.user_id === C.uid; })[0], admin = me && me.role === 'admin';
      var m = C.modal({
        title: c.title || 'گروه', body: '<div class="ulist">' + st.members.map(function (x) { var u = C.user(x.user_id); return '<a class="uitem" href="#/u/' + esc(u.username) + '" data-close>' + C.avatar(u, 40) + '<span><b>' + esc(C.name(u)) + C.badge(u) + '</b><small>@' + esc(u.username) + (x.role === 'admin' ? ' · مدیر' : '') + '</small></span></a>'; }).join('') + '</div>' +
          (admin ? '<label class="field"><span>افزودن عضو</span><input class="input" id="am" placeholder="نام کاربری…" autocomplete="off"></label><div class="ulist" id="ar"></div>' : ''),
        actions: [{ label: 'ترک گروه', kind: 'danger', onClick: async function (a) { if (!(await C.confirm({ title: 'ترک گروه', text: 'از این گروه خارج شوی؟', ok: 'خروج', danger: true }))) return; await sb.rpc('leave_conversation', { p_conv: st.active }); a.close(); await C.refreshBadges(); C.go('/chat'); } }, { label: 'بستن', onClick: function (a) { a.close(); } }]
      });
      var am = $('#am', m.el);
      if (am) {
        am.addEventListener('input', C.debounce(async function () {
          var us = (await findUsers(am.value)).filter(function (u) { return !st.members.some(function (x) { return x.user_id === u.id; }); });
          $('#ar', m.el).innerHTML = us.map(function (u) { return '<button class="uitem" data-u="' + u.id + '">' + C.avatar(u, 40) + '<span><b>' + esc(C.name(u)) + '</b><small>@' + esc(u.username) + '</small></span></button>'; }).join('');
        }, 300));
        m.el.addEventListener('click', async function (e) {
          var b = e.target.closest('[data-u]'); if (!b) return;
          var r = await sb.rpc('add_group_members', { p_conv: st.active, p_members: [b.getAttribute('data-u')] }); if (r.error) return C.toast(C.err(r.error), 'bad');
          C.toast('عضو اضافه شد'); m.close(); await C.refreshBadges(); openConv(st.active);
        });
      }
    }

    /* ----- live ----- */
    var offs = [];
    offs.push(C.on('message', function (m) {
      if (st.dead) return;
      if (m.sender_id !== C.uid && m.conversation_id === st.active && !st.msgs.some(function (x) { return x.id === m.id; })) {
        C.hydrate([m], 'sender_id').then(function () { st.msgs.push(m); renderMsgs(); if (document.hasFocus()) markRead(); });
      }
      if (m.sender_id !== C.uid) { var c = C.convs.filter(function (x) { return x.conv_id === m.conversation_id; })[0]; if (c && c.kind === 'direct') C.hydrate([c], 'other_id'); }
      renderList();
    }));
    offs.push(C.on('presence', function () { renderList(); renderHead(); }));
    var foc = function () { if (st.active && document.hasFocus()) markRead(); }; window.addEventListener('focus', foc);

    renderList();
    if (ctx.params.id) await openConv(ctx.params.id); else { C.chatState.active = null; thread.innerHTML = C.empty('chat', 'یک گفتگو را انتخاب کن', 'یا با دکمه‌ی بالا چت جدید بساز.'); }
    return function () {
      st.dead = true; C.chatState.active = null; offs.forEach(function (f) { f(); }); window.removeEventListener('focus', foc);
      if (st.tch) sb.removeChannel(st.tch);
    };
  }
})();
