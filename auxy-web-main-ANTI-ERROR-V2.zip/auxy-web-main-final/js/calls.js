/* Auxy WebRTC calls: private + small group mesh, using Supabase Realtime signaling. */
(function(){
  'use strict';
  var A=window.AUXY,C=A.core,sb=A.client,esc=C.esc,$=C.$, state=null;
  A.calls={open:open,close:close,listen:listen};
  var listeners={};
  async function listen(convId,members){ if(listeners[convId])return; var ch=sb.channel('call:'+convId); listeners[convId]=ch; ch.on('broadcast',{event:'start'},function(e){var x=e.payload||{};if(x.from===C.uid)return; if(state)return; var ok=window.confirm((x.kind==='video'?'تماس تصویری':'تماس صوتی')+' ورودی از یک کاربر. قبول می‌کنی؟'); if(ok)open(convId,members,x.kind);}); await ch.subscribe(); }

  function close(){if(!state)return;Object.keys(state.peers).forEach(function(k){try{state.peers[k].close();}catch(e){}});if(state.stream)state.stream.getTracks().forEach(function(t){t.stop();});if(state.ch)sb.removeChannel(state.ch);if(state.modal)state.modal.close();state=null;}
  async function open(convId,members,kind){
    if(state)close();
    kind=kind||'audio'; var ids=(members||[]).map(function(x){return x.user_id||x;}).filter(function(x){return x!==C.uid;});
    var room='call:'+convId, local=await navigator.mediaDevices.getUserMedia({audio:true,video:kind==='video'});
    var m=C.modal({title:kind==='video'?'تماس تصویری':'تماس صوتی',wide:true,cls:'call-modal',body:'<div class="call-stage"><video id="callLocal" autoplay muted playsinline></video><div id="callPeers" class="call-peers"></div></div><div class="call-status" id="callStatus">در حال اتصال…</div>',actions:[{label:'پایان تماس',kind:'danger',onClick:function(a){close();}}]});
    $('#callLocal',m.el).srcObject=local;
    state={convId:convId,kind:kind,ids:ids,stream:local,peers:{},modal:m,ch:null};
    function pc(peer){if(state.peers[peer])return state.peers[peer];var p=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun.cloudflare.com:3478'}]});local.getTracks().forEach(function(t){p.addTrack(t,local);});p.onicecandidate=function(e){if(e.candidate)state.ch.send({type:'broadcast',event:'ice',payload:{from:C.uid,to:peer,candidate:e.candidate}});};p.ontrack=function(e){var id='peer-'+peer.replace(/[^a-z0-9]/gi,'');var v=document.getElementById(id);if(!v){v=document.createElement('video');v.id=id;v.autoplay=true;v.playsInline=true;v.className='call-peer';$('#callPeers',m.el).appendChild(v);}v.srcObject=e.streams[0];};p.onconnectionstatechange=function(){if(p.connectionState==='connected')$('#callStatus',m.el).textContent='متصل';};state.peers[peer]=p;return p;}
    state.ch=sb.channel(room);
    state.ch.on('broadcast',{event:'offer'},async function(e){var x=e.payload||{};if(x.to!==C.uid)return;var p=pc(x.from);await p.setRemoteDescription(x.offer);var ans=await p.createAnswer();await p.setLocalDescription(ans);state.ch.send({type:'broadcast',event:'answer',payload:{from:C.uid,to:x.from,answer:ans}});});
    state.ch.on('broadcast',{event:'answer'},async function(e){var x=e.payload||{};if(x.to!==C.uid)return;var p=state.peers[x.from];if(p)await p.setRemoteDescription(x.answer);});
    state.ch.on('broadcast',{event:'ice'},async function(e){var x=e.payload||{};if(x.to!==C.uid)return;var p=state.peers[x.from];if(p)try{await p.addIceCandidate(x.candidate);}catch(err){}});
    await state.ch.subscribe();
    state.ch.send({type:'broadcast',event:'start',payload:{from:C.uid,kind:kind}});
    // Caller creates offers. Everyone who opens the call can join and establish a mesh.
    for(var i=0;i<ids.length;i++){var p=pc(ids[i]),offer=await p.createOffer();await p.setLocalDescription(offer);state.ch.send({type:'broadcast',event:'offer',payload:{from:C.uid,to:ids[i],offer:offer}});}
    $('#callStatus',m.el).textContent=ids.length?'در انتظار پاسخ…':'تنها در تماس';
  }
})();
