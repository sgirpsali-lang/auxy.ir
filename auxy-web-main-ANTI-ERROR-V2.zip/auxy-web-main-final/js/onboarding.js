/* Auxy web: first-time setup (username -> password -> final confirm).
   Loaded only when the account is not fully set up, and never shown again afterwards. */
(function () {
  'use strict';
  var A = window.AUXY, C = A.core, S = A.sec, sb = A.client, esc = C.esc, $ = C.$;
  A.mod.onboarding = { run: run };

  function run() {
    return new Promise(function (resolve) {
      var me = C.me, p = me.profile, pv = me.priv;
      var reset = !!(p.username && pv.onboarded && !pv.password_set);   // owner reset the password
      var step = !p.username ? 1 : (!pv.password_set ? 2 : 3);
      var pwd = '';

      var root = C.el('<div class="ob" role="dialog" aria-modal="true" aria-label="ساخت حساب">' +
        '<div class="ob-bg" aria-hidden="true"></div>' +
        '<div class="ob-card" data-tilt="3"><div class="ob-dots" aria-hidden="true"></div><div class="ob-body"></div>' +
        '<button class="ob-out" type="button">خروج از حساب</button></div></div>');
      document.body.appendChild(root);
      var body = $('.ob-body', root);
      $('.ob-out', root).addEventListener('click', function () { A.signOut(); });
      S.wireEyes(root);

      function dots() {
        var n = reset ? [2, 3] : [1, 2, 3];
        $('.ob-dots', root).innerHTML = n.map(function (i) { return '<i class="' + (i === step ? 'on' : (i < step ? 'done' : '')) + '"></i>'; }).join('');
      }
      function go(n) { step = n; dots(); body.classList.remove('in'); void body.offsetWidth; (n === 1 ? step1 : n === 2 ? step2 : step3)(); body.classList.add('in'); }

      /* ---------- step 1: username ---------- */
      function step1() {
        var first = String(C.name(p) || '').split(' ')[0];
        body.innerHTML = '<div class="ob-mark">' + C.logo() + '</div><h1>سلام' + (first ? ' ' + esc(first) : '') + '!</h1>' +
          '<p class="sub">یک نام کاربری برای خودت انتخاب کن. بقیه با همین نام پیدایت می‌کنند.</p>' +
          '<label class="field"><span>نام کاربری</span><div class="un-wrap"><b>@</b><input class="input ltr" id="un" maxlength="30" autocomplete="off" autocapitalize="off" spellcheck="false" inputmode="latin" placeholder="username"></div></label>' +
          '<div class="un-status" id="uns" aria-live="polite"></div><ul class="rules" id="ur"></ul>' +
          '<div class="chips" id="usug" aria-label="پیشنهاد"></div>' +
          '<button class="btn primary block" id="next" disabled>ادامه</button>' +
          '<p class="fine">حروف بزرگ خودکار کوچک می‌شوند. بعداً هر ۱۴ روز یک‌بار می‌توانی نام کاربری را عوض کنی.</p>';
        var un = $('#un', body), uns = $('#uns', body), ur = $('#ur', body), next = $('#next', body), token = 0, okName = '';
        function rules() { ur.innerHTML = S.usernameRules(un.value).map(function (r) { return '<li class="' + (r.ok ? 'ok' : '') + '">' + C.icon('check', { size: 14, sw: 2.6 }) + '<span>' + r.label + '</span></li>'; }).join(''); }
        function status(cls, txt) { uns.className = 'un-status ' + cls; uns.textContent = txt; }
        var remote = C.debounce(async function (val, t) {
          var r = await S.checkUsername(val);
          if (t !== token) return;
          if (r.ok) { okName = val; status('ok', 'آزاد است ✓  @' + val); next.disabled = false; }
          else status('bad', S.usernameMsg(r.code));
        }, 380);
        function check() {
          var v = un.value.toLowerCase(); token++; okName = ''; next.disabled = true; rules();
          if (!v) return status('', '');
          var e = S.usernameError(v);
          if (e) return status('bad', S.usernameMsg(e));
          status('wait', 'در حال بررسی…'); remote(v, token);
        }
        un.addEventListener('input', check);
        un.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !next.disabled) next.click(); });
        function sanitize(s) { return String(s || '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9_]/g, ''); }
        var seeds = [sanitize(String(me.email || '').split('@')[0]), sanitize(C.name(p))].filter(function (s) { return s.length >= 3; });
        var sug = [];
        seeds.forEach(function (s) { s = s.slice(0, 18); if (sug.indexOf(s) < 0) sug.push(s); sug.push(s + '_' + Math.floor(10 + Math.random() * 90)); });
        $('#usug', body).innerHTML = sug.slice(0, 4).map(function (s) { return '<button type="button" class="chip" data-s="' + esc(s) + '">@' + esc(s) + '</button>'; }).join('');
        $('#usug', body).addEventListener('click', function (e) { var b = e.target.closest('[data-s]'); if (b) { un.value = b.getAttribute('data-s'); check(); un.focus(); } });
        next.addEventListener('click', async function () {
          if (!okName) return;
          next.disabled = true; status('wait', 'در حال ثبت…');
          var r = await sb.rpc('claim_username', { p_username: okName });
          var d = r.data;
          if (r.error || !d || !d.ok) {
            if (d && d.code === 'already_set') { await C.reloadMe(); p = C.me.profile; return go(2); }
            status('bad', S.usernameMsg(d && d.code)); next.disabled = false; return;
          }
          p.username = d.username; p.role = d.role || p.role; C.users[p.id] = p;
          go(2);
        });
        rules(); setTimeout(function () { un.focus(); }, 80);
      }

      /* ---------- step 2: password ---------- */
      function step2() {
        body.innerHTML = '<div class="ob-mark ic-round">' + C.icon('lock', { size: 30 }) + '</div>' +
          '<h1>' + (reset ? 'یک رمز امنیتی جدید بساز' : 'حالا یک رمز امنیتی بساز') + '</h1>' +
          '<p class="sub">این رمز، رمز اصلی ورود تو به Auxy است. برای امنیت، آن را با کسی به اشتراک نگذار.</p>' +
          '<div class="warn" role="note">' + C.icon('info', { size: 20 }) + '<div><b>رمزت را فراموش نکن!</b><span>برای بازیابی، ایمیل بازیابی در صورت تمایل قابل ثبت است؛ ثبت ایمیل اجباری نیست.</span></div></div>' +
          S.pwField('pw1', 'رمز امنیتی', 'new-password') + S.pwField('pw2', 'تکرار رمز', 'new-password') +
          '<div class="pw-tools"><button type="button" class="chip" id="gen">' + C.icon('sparkle', { size: 15 }) + 'پیشنهاد یک رمز قوی</button><button type="button" class="chip" id="cp" hidden>' + C.icon('copy', { size: 15 }) + 'کپی</button></div>' +
          '<div id="meter"></div><div class="form-err" id="perr" hidden></div>' +
          '<button class="btn primary block" id="next" disabled>ادامه</button>';
        var p1 = $('#pw1', body), p2 = $('#pw2', body), next = $('#next', body), perr = $('#perr', body);
        var meter = S.meter($('#meter', body), function () { return { username: p.username, email: me.email }; });
        function upd() {
          var r = meter.update(p1.value), match = p2.value && p1.value === p2.value;
          if (p2.value && !match) { perr.textContent = 'تکرار رمز با رمز بالا یکی نیست.'; perr.hidden = false; } else perr.hidden = true;
          next.disabled = !(r.ok && match);
        }
        p1.addEventListener('input', upd); p2.addEventListener('input', upd);
        [p1, p2].forEach(function (i) { i.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !next.disabled) next.click(); }); });
        $('#gen', body).addEventListener('click', function () {
          var g = S.generate(16); p1.value = g; p2.value = g; p1.type = 'text'; p2.type = 'text'; upd();
          $('#cp', body).hidden = false; C.toast('رمز ساخته شد. حتماً جایی ذخیره‌اش کن.');
        });
        $('#cp', body).addEventListener('click', function () { C.copy(p1.value); });
        next.addEventListener('click', function () { pwd = p1.value; go(3); });
        upd(); setTimeout(function () { p1.focus(); }, 80);
      }

      /* ---------- step 3: final confirm ---------- */
      function step3() {
        body.innerHTML = '<div class="ob-mark ic-round">' + C.icon('shield', { size: 30 }) + '</div><h1>تأیید نهایی</h1>' +
          '<p class="sub">همه‌چیز را یک بار مرور کن. بعد از تأیید، این صفحه‌ها دیگر نشان داده نمی‌شوند.</p>' +
          '<div class="sum"><div><small>نام کاربری</small><b class="ltr">@' + esc(p.username) + '</b></div>' +
          '<div><small>رمز امنیتی</small><b class="ltr" id="masked">' + '•'.repeat(Math.min(pwd.length, 14)) + '</b><button type="button" class="icon-btn" id="tg" aria-label="نمایش رمز">' + C.icon('eye', { size: 18 }) + '</button></div></div>' +
          '<div class="warn" role="note">' + C.icon('info', { size: 20 }) + '<div><b>یادآوری</b><span>ایمیل بازیابی اختیاری است و می‌توانی بعداً از تنظیمات اضافه یا تغییرش بدهی.</span></div></div>' +
          '<label class="check"><input type="checkbox" id="ok"><span>متوجه‌ام و رمزم را جایی امن نگه می‌دارم.</span></label>' +
          '<div class="form-err" id="ferr" hidden></div>' +
          '<div class="row-btns"><button class="btn ghost" id="back">بازگشت</button><button class="btn primary grow" id="fin" disabled>تأیید و ورود به Auxy</button></div>';
        var ok = $('#ok', body), fin = $('#fin', body), ferr = $('#ferr', body), shown = false;
        ok.addEventListener('change', function () { fin.disabled = !ok.checked; });
        $('#tg', body).addEventListener('click', function () {
          shown = !shown; $('#masked', body).textContent = shown ? pwd : '•'.repeat(Math.min(pwd.length, 14));
          this.innerHTML = C.icon(shown ? 'eyeoff' : 'eye', { size: 18 });
        });
        $('#back', body).addEventListener('click', function () { go(2); });
        fin.addEventListener('click', async function () {
          fin.disabled = true; ferr.hidden = true; fin.textContent = 'در حال ذخیره…';
          try {
            var r = await sb.rpc('set_app_password', { p_password: pwd });
            if (r.error) throw r.error;
            if (!r.data.ok && r.data.code !== 'already_set') { ferr.textContent = S.pwMsg(r.data); ferr.hidden = false; fin.disabled = false; fin.textContent = 'تأیید و ورود به Auxy'; if (r.data.code !== 'no_username') go(2); return; }
            if (!reset) {
              var f = await sb.rpc('finish_onboarding');
              if (f.error || !f.data || !f.data.ok) throw new Error('finish');
            }
            pwd = '';
            body.innerHTML = '<div class="ob-mark ic-round ok">' + C.icon('check', { size: 34, sw: 2.6 }) + '</div><h1>همه‌چیز آماده است</h1><p class="sub">به Auxy خوش آمدی @' + esc(p.username) + '</p>';
            setTimeout(function () { root.classList.add('out'); setTimeout(function () { root.remove(); resolve(); }, 450); }, 900);
          } catch (e) {
            ferr.textContent = C.err(e); ferr.hidden = false; fin.disabled = false; fin.textContent = 'تأیید و ورود به Auxy';
          }
        });
      }

      dots(); (step === 1 ? step1 : step === 2 ? step2 : step3)(); body.classList.add('in');
    });
  }
})();
