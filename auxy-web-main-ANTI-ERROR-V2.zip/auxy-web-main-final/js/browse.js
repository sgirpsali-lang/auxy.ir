/* Auxy web: main page (Netflix-style): hero, rows, genres, movie page, my list, search */
(function () {
  'use strict';
  var A = window.AUXY, C = A.core, sb = A.client, esc = C.esc, $ = C.$;
  var B = A.mod.browse = { home: home, genre: genre, movie: movie, mylist: mylist, search: search, explore: explore, series:series, seriesDetail:seriesDetail, episode:episode };
  var MAT = { all: 'همه‌سنین', '7': '+۷', '13': '+۱۳', '16': '+۱۶', '18': '+۱۸' };
  A.MATURITY = MAT;
  var D = { movies: null, series: [], byId: {}, list: new Set(), progress: {}, order: [], likes: new Set(), at: 0 };

  async function data(force) {
    if (!force && D.movies && Date.now() - D.at < 60000) return D;
    var r = await Promise.all([
      C.withTimeout(sb.from('movies').select('*').order('created_at', { ascending: false }).limit(300),10000,'فیلم‌ها'),
      C.withTimeout(sb.from('my_list').select('movie_id,created_at').eq('user_id', C.uid).order('created_at', { ascending: false }),10000,'لیست من'),
      C.withTimeout(sb.from('watch_progress').select('*').eq('user_id', C.uid).order('updated_at', { ascending: false }).limit(60),10000,'پیشرفت تماشا'),
      C.withTimeout(sb.from('movie_likes').select('movie_id').eq('user_id', C.uid),10000,'لایک‌ها'),
      C.withTimeout(sb.from('series').select('*').eq('published',true).order('created_at',{ascending:false}).limit(100),10000,'سریال‌ها')
    ]);
    D.movies = r[0].data || []; D.byId = {}; D.movies.forEach(function (m) { D.byId[m.id] = m; });
    D.list = new Set((r[1].data || []).map(function (x) { return x.movie_id; }));
    D.progress = {}; D.order = [];
    (r[2].data || []).forEach(function (p) { D.progress[p.movie_id] = p; D.order.push(p.movie_id); });
    D.likes = new Set((r[3].data || []).map(function (x) { return x.movie_id; })); D.series = r[4].data || [];
    D.at = Date.now(); return D;
  }
  B.invalidate = function () { D.at = 0; };
  B.setProgress = function (id, pos, dur) {
    D.progress[id] = { movie_id: id, position_seconds: pos, duration_seconds: dur };
    D.order = [id].concat(D.order.filter(function (x) { return x !== id; }));
  };
  B.progressOf = function (id) { return D.progress[id]; };

  /* ---------- formatting ---------- */
  function fdur(min) {
    if (!min) return '';
    var h = Math.floor(min / 60), m = min % 60;
    return (h ? C.fa(h) + ' ساعت' : '') + (h && m ? ' و ' : '') + (m ? C.fa(m) + ' دقیقه' : '');
  }
  function meta(m) {
    var a = [];
    if (m.year) a.push(C.fa(m.year).replace(/٬/g, ''));
    var d = fdur(m.duration_minutes); if (d) a.push(d);
    if (m.maturity && MAT[m.maturity]) a.push('<span class="mat">' + MAT[m.maturity] + '</span>');
    return a.join('<i>·</i>');
  }
  function poster(m, o) {
    o = o || {};
    var pr = D.progress[m.id], pct = pr && pr.duration_seconds ? Math.min(100, Math.round(pr.position_seconds / pr.duration_seconds * 100)) : 0;
    return '<a class="poster" href="#/movie/' + m.id + '" data-tilt="8" title="' + esc(m.title) + '"><div class="poster-img">' +
      '<div class="poster-fb"><b>' + esc(m.title) + '</b></div>' +
      (m.poster_url ? '<img src="' + esc(m.poster_url) + '" alt="" loading="lazy" decoding="async" onerror="this.remove()">' : '') + '</div>' +
      '<div class="poster-ov"><b>' + esc(m.title) + '</b><span>' + meta(m) + '</span></div>' +
      (!m.published ? '<span class="draft">پیش‌نویس</span>' : '') +
      '<button class="poster-add' + (D.list.has(m.id) ? ' on' : '') + '" data-list="' + m.id + '" aria-label="لیست من">' + C.icon(D.list.has(m.id) ? 'check' : 'plus', { size: 18 }) + '</button>' +
      (o.progress && pct ? '<div class="poster-prog"><i style="width:' + pct + '%"></i></div>' : '') + '</a>';
  }
  function row(title, items, o) {
    o = o || {};
    return '<section class="row"><div class="row-h"><h2>' + esc(title) + '</h2>' + (o.more ? '<a href="' + o.more + '">همه ' + C.icon('chevL', { size: 16 }) + '</a>' : '') + '</div>' +
      '<div class="row-w"><button class="row-nav prev" data-dir="1" aria-label="قبلی">' + C.icon('chevR', { size: 22 }) + '</button><div class="row-s">' +
      items.map(function (m) { return poster(m, o); }).join('') + '</div><button class="row-nav next" data-dir="-1" aria-label="بعدی">' + C.icon('chevL', { size: 22 }) + '</button></div></section>';
  }
  function grid(items) { return '<div class="grid-posters">' + items.map(function (m) { return poster(m); }).join('') + '</div>'; }
  function genresOf(movies) {
    var g = {};
    movies.forEach(function (m) { (m.genres || []).forEach(function (x) { (g[x] = g[x] || []).push(m); }); });
    return g;
  }
  function chips(all, cur) {
    var names = Object.keys(all);
    if (!names.length) return '';
    return '<div class="chips scroll-x"><a class="chip' + (!cur ? ' on' : '') + '" href="#/">همه</a>' +
      names.map(function (n) { return '<a class="chip' + (n === cur ? ' on' : '') + '" href="#/genre/' + encodeURIComponent(n) + '">' + esc(n) + '</a>'; }).join('') + '</div>';
  }
  function hero(m) {
    var pr = D.progress[m.id], bg = m.backdrop_url || m.poster_url;
    return '<section class="hero" id="hero">' +
      (bg ? '<img class="hero-bg" src="' + esc(bg) + '" alt="" fetchpriority="high" decoding="async" onerror="this.remove()">' : '<div class="hero-bg art"></div>') +
      '<div class="hero-shade"></div><div class="hero-in"><div class="kicker">' + (m.featured ? 'ویژه‌ی Auxy' : 'تازه') + '</div>' +
      '<h1>' + esc(m.title) + '</h1><div class="meta">' + meta(m) + '</div>' +
      (m.description ? '<p class="clamp">' + esc(m.description) + '</p>' : '') +
      '<div class="hero-btns"><button class="btn primary big" data-play="' + m.id + '">' + C.icon('play', { size: 20, fill: true }) + (pr && pr.position_seconds > 20 ? 'ادامه تماشا' : 'پخش') + '</button>' +
      '<button class="btn glass big" data-list="' + m.id + '">' + C.icon(D.list.has(m.id) ? 'check' : 'plus', { size: 20 }) + 'لیست من</button>' +
      '<a class="btn glass big" href="#/movie/' + m.id + '">' + C.icon('info', { size: 20 }) + 'اطلاعات</a></div></div></section>';
  }

  /* ---------- shared interactions ---------- */
  function wire(el) {
    el.addEventListener('click', function (e) {
      var l = e.target.closest('[data-list]');
      if (l) { e.preventDefault(); e.stopPropagation(); return toggleList(l.getAttribute('data-list')); }
      var p = e.target.closest('[data-play]');
      if (p) { e.preventDefault(); return play(p.getAttribute('data-play')); }
      var n = e.target.closest('.row-nav');
      if (n) { var s = n.parentNode.querySelector('.row-s'); s.scrollBy({ left: Number(n.getAttribute('data-dir')) * s.clientWidth * .85, behavior: C.motionOn() ? 'smooth' : 'auto' }); }
    });
    var h = $('#hero', el);
    if (h && C.motionOn() && matchMedia('(hover:hover) and (pointer:fine)').matches) {
      var raf = 0;
      h.addEventListener('pointermove', function (e) {
        if (raf) return;
        raf = requestAnimationFrame(function () {
          raf = 0; var r = h.getBoundingClientRect();
          h.style.setProperty('--px', ((e.clientX - r.left) / r.width - .5).toFixed(3));
          h.style.setProperty('--py', ((e.clientY - r.top) / r.height - .5).toFixed(3));
        });
      });
    }
  }
  async function toggleList(id) {
    var on = D.list.has(id);
    on ? D.list.delete(id) : D.list.add(id);
    C.$$('[data-list="' + id + '"]').forEach(function (b) {
      b.classList.toggle('on', !on);
      var ic = b.querySelector('.ic'); if (ic) ic.outerHTML = C.icon(!on ? 'check' : 'plus', { size: b.classList.contains('poster-add') ? 18 : 20 });
    });
    var r = on ? await sb.from('my_list').delete().eq('user_id', C.uid).eq('movie_id', id) : await sb.from('my_list').insert({ user_id: C.uid, movie_id: id });
    if (r.error) { on ? d.likes.add(m.id) : d.likes.delete(m.id); likes += on ? 1 : -1; m.likes_count = likes; lb.setAttribute('aria-pressed', on); lb.innerHTML = C.icon('heart',{size:20,fill:on})+'<span>'+C.compact(likes)+'</span>'; C.toast(C.err(r.error),'bad'); } else C.toast(on ? 'از لیست شما حذف شد' : 'به لیست شما اضافه شد');
  }
  async function play(id) {
    var m = D.byId[id]; if (!m) return;
    await C.load('player');
    A.mod.player.open(m, { resume: D.progress[id] });
  }
  B.play = play;

  /* ---------- explore ---------- */
  async function explore(ctx) {
    var el = ctx.el; el.innerHTML = '<div class="page-pad"><h1 class="page-h">اکتشاف</h1><div class="explore-grid"><a class="glass-card" href="#/search"><b>جستجوی همه‌چیز</b><span>فیلم، سریال، دراما و کاربران</span></a><a class="glass-card" href="#/genre/درام"><b>دراما</b><span>داستان‌های سریالی و درام</span></a><a class="glass-card" href="#/scroll"><b>اسکرول</b><span>محتوای اجتماعی کوتاه</span></a><a class="glass-card" href="#/mylist"><b>لیست من</b><span>ادامه‌ی تماشا و ذخیره‌ها</span></a></div><div id="exploreRows"></div></div>';
    var d = await data(); var movies = d.movies.filter(function(m){return m.published;});
    var groups = {}; movies.forEach(function(m){var k=m.content_type||'movie';(groups[k]=groups[k]||[]).push(m);});
    $('#exploreRows',el).innerHTML = (groups.series&&groups.series.length ? row('سریال‌ها',groups.series,{more:'#/genre/سریال'}) : '') + (groups.drama&&groups.drama.length ? row('دراما',groups.drama,{more:'#/genre/درام'}) : '') + (groups.movie&&groups.movie.length ? row('فیلم‌ها',groups.movie) : '');
    wire(el);
  }

  /* ---------- series ---------- */
  function seriesTile(x){return '<a class="poster series-poster" href="#/series/'+x.id+'" data-tilt="6"><div class="poster-img"><div class="poster-fb"><b>'+esc(x.title)+'</b></div>'+(x.poster_url?'<img src="'+esc(x.poster_url)+'" alt="" loading="lazy">':'')+'</div><div class="poster-ov"><b>'+esc(x.title)+'</b><span>'+(x.year?C.fa(x.year):'')+'</span></div></a>';}
  async function series(ctx){var el=ctx.el;el.innerHTML='<div class="page-pad"><h1 class="page-h">سریال‌ها</h1><div class="grid-posters" id="sg"><div class="sk sk-grid"></div></div></div>';try{var r=await C.withTimeout(sb.from('series').select('*').eq('published',true).order('created_at',{ascending:false}).limit(200),10000,'سریال‌ها');if(r.error)throw r.error;$('#sg',el).innerHTML=(r.data||[]).map(seriesTile).join('')||C.empty('film','هنوز سریالی منتشر نشده');}catch(e){$('#sg',el).innerHTML=C.empty('info','سریال‌ها بارگذاری نشد',C.err(e),'<button class="btn primary" onclick="location.reload()">تلاش دوباره</button>');}}
  async function seriesDetail(ctx){var el=ctx.el,id=ctx.params.id;el.innerHTML='<div class="page-pad"><div class="sk sk-hero sk"></div></div>';try{var r=await C.withTimeout(Promise.all([sb.from('series').select('*').eq('id',id).maybeSingle(),sb.from('seasons').select('*').eq('series_id',id).order('season_number')]),10000,'سریال');if(r[0].error)throw r[0].error;var x=r[0].data;if(!x){el.innerHTML=C.empty('film','سریال پیدا نشد');return;}var ss=r[1].data||[],html='<section class="hero series-hero">'+(x.backdrop_url?'<img class="hero-bg" src="'+esc(x.backdrop_url)+'" alt="">':'<div class="hero-bg art"></div>')+'<div class="hero-shade"></div><div class="hero-in"><div class="kicker">سریال</div><h1>'+esc(x.title)+'</h1><div class="meta">'+(x.year?C.fa(x.year):'')+'</div>'+(x.description?'<p class="clamp">'+esc(x.description)+'</p>':'')+'</div></section><div class="series-detail">';for(var i=0;i<ss.length;i++){var ep=await C.withTimeout(sb.from('episodes').select('*').eq('season_id',ss[i].id).eq('published',true).order('episode_number'),8000,'قسمت‌ها');var eps=ep.data||[];html+='<section class="season"><div class="season-head"><h2>فصل '+C.fa(ss[i].season_number)+(ss[i].title?' · '+esc(ss[i].title):'')+'</h2></div><div class="episode-list">'+eps.map(function(e){return '<a class="episode" href="#/episode/'+e.id+'"><b>'+C.fa(e.episode_number)+'</b><span><strong>'+esc(e.title)+'</strong><small>'+esc(e.description||'')+'</small></span><i>'+C.icon('play',{size:17})+'</i></a>';}).join('')+'</div></section>';}html+='</div>';el.innerHTML=html;}catch(e){el.innerHTML=C.empty('info','سریال بارگذاری نشد',C.err(e),'<button class="btn primary" onclick="location.reload()">تلاش دوباره</button>');}}
  async function episode(ctx){var el=ctx.el,id=ctx.params.id;el.innerHTML='<div class="page-pad"><div class="sk sk-grid"></div></div>';try{var r=await C.withTimeout(sb.from('episodes').select('*,seasons!inner(series_id,series(title))').eq('id',id).maybeSingle(),10000,'قسمت');if(r.error)throw r.error;if(!r.data){el.innerHTML=C.empty('film','قسمت پیدا نشد');return;}var e=r.data,x=e.seasons&&e.seasons.series;await C.load('player');A.mod.player.open({id:e.id,title:(x&&x.title?x.title+' — ':'')+e.title,video_url:e.video_url,video_kind:e.video_kind,duration_minutes:e.duration_minutes,poster_url:e.poster_url,kind:'episode'},{episodeId:e.id,nextUrl:x?'#/series/'+e.seasons.series_id:null});el.innerHTML='<div class="page-pad"><p class="muted">در حال آماده‌سازی پخش…</p></div>';}catch(err){el.innerHTML=C.empty('info','قسمت بارگذاری نشد',C.err(err));}}

  /* ---------- home ---------- */
  function skelHome() {
    return '<div class="sk-hero sk"></div>' + [1, 2].map(function () { return '<div class="row"><div class="sk sk-title"></div><div class="row-s">' + C.skel(7, 'sk-poster') + '</div></div>'; }).join('');
  }
  async function home(ctx) {
    var el = ctx.el; el.innerHTML = skelHome();
    var d = await data();
    var movies = d.movies.filter(function (m) { return m.published; });
    if (!movies.length) {
      el.innerHTML = '<section class="hero empty-hero"><div class="hero-bg art"></div><div class="hero-shade"></div><div class="hero-in"><div class="kicker">Auxy</div><h1>کتابخانه هنوز خالی است</h1>' +
        '<p>فیلم‌ها به‌زودی اینجا اضافه می‌شوند. تا آن موقع می‌توانی اسکرول را ببینی یا با دوستانت چت کنی.</p><div class="hero-btns">' +
        (C.isPublisher() ? '<a class="btn primary big" href="#/studio">' + C.icon('plus', { size: 20 }) + 'افزودن اولین فیلم</a>' : '') +
        '<a class="btn glass big" href="#/scroll">' + C.icon('scroll', { size: 20 }) + 'اسکرول</a><a class="btn glass big" href="#/chat">' + C.icon('chat', { size: 20 }) + 'چت</a></div></div></section>';
      return;
    }
    var hm = movies.filter(function (m) { return m.featured; })[0] || movies[0];
    var g = genresOf(movies), html = hero(hm) + '<div class="rows">' + chips(g);
    var cont = d.order.map(function (id) { return d.byId[id]; }).filter(function (m) {
      var p = m && d.progress[m.id]; return m && m.published && p && p.duration_seconds && p.position_seconds / p.duration_seconds > .02 && p.position_seconds / p.duration_seconds < .95;
    });
    if (cont.length) html += row('ادامه تماشا', cont.slice(0, 20), { progress: true });
    var mine = movies.filter(function (m) { return d.list.has(m.id); });
    if (mine.length) html += row('لیست من', mine.slice(0, 20), { more: '#/mylist' });
    html += row('تازه‌ها', movies.slice(0, 20));
    var series = d.series || [];
    var dramas = movies.filter(function(m){return (m.content_type||'movie')==='drama';});
    if(series.length) html += row('سریال‌ها', series.slice(0,20), {more:'#/genre/سریال'});
    if(dramas.length) html += row('دراما', dramas.slice(0,20), {more:'#/genre/دراما'});
    var pop = movies.filter(function (m) { return m.views > 0; }).sort(function (a, b) { return b.views - a.views; }).slice(0, 15);
    if (pop.length) html += row('پربازدیدترین‌ها', pop);
    Object.keys(g).slice(0, 8).forEach(function (n) { html += row(n, g[n].slice(0, 20), { more: '#/genre/' + encodeURIComponent(n) }); });
    el.innerHTML = html + '</div>';
    wire(el);
  }

  async function genre(ctx) {
    var el = ctx.el, d = await data(), name = ctx.params.g;
    var movies = d.movies.filter(function (m) { return m.published; }), g = genresOf(movies), items = g[name] || [];
    el.innerHTML = '<div class="page-pad"><h1 class="page-h">' + esc(name) + '</h1>' + chips(g, name) +
      (items.length ? grid(items) : C.empty('film', 'فیلمی در این دسته نیست', '', '<a class="btn primary" href="#/">بازگشت</a>')) + '</div>';
    wire(el);
  }
  async function mylist(ctx) {
    var el = ctx.el, d = await data();
    var items = d.movies.filter(function (m) { return d.list.has(m.id) && (m.published || C.isPublisher()); });
    el.innerHTML = '<div class="page-pad"><h1 class="page-h">لیست من</h1>' +
      (items.length ? grid(items) : C.empty('list', 'لیست شما خالی است', 'روی + کنار هر فیلم بزنید تا برای بعد ذخیره شود.', '<a class="btn primary" href="#/">دیدن فیلم‌ها</a>')) + '</div>';
    wire(el);
  }

  /* ---------- movie page ---------- */
  async function movie(ctx) {
    var el = ctx.el, d = await data(), id = ctx.params.id, m = d.byId[id];
    if (!m) { var r = await sb.from('movies').select('*').eq('id', id).maybeSingle(); m = r.data; if (m) d.byId[m.id] = m; }
    if (!m) { el.innerHTML = C.empty('film', 'این فیلم پیدا نشد', 'ممکن است حذف شده باشد.', '<a class="btn primary" href="#/">بازگشت</a>'); return; }
    var pr = d.progress[m.id], liked = d.likes.has(m.id), likes = m.likes_count || 0, bg = m.backdrop_url || m.poster_url;
    var sim = d.movies.filter(function (x) { return x.id !== m.id && x.published && (x.genres || []).some(function (g) { return (m.genres || []).indexOf(g) > -1; }); }).slice(0, 14);
    el.innerHTML = '<section class="mv" id="mv">' + (bg ? '<img class="mv-bg" src="' + esc(bg) + '" alt="" decoding="async" onerror="this.remove()">' : '') + '<div class="mv-shade"></div>' +
      '<div class="mv-in"><div class="mv-poster" data-tilt="10">' + (m.poster_url ? '<img src="' + esc(m.poster_url) + '" alt="' + esc(m.title) + '">' : '<div class="poster-fb"><b>' + esc(m.title) + '</b></div>') + '</div>' +
      '<div class="mv-info">' + (!m.published ? '<span class="draft static">پیش‌نویس (فقط ناشران می‌بینند)</span>' : '') + '<h1>' + esc(m.title) + '</h1><div class="meta">' + meta(m) + '</div>' +
      '<div class="hero-btns"><button class="btn primary big" data-play="' + m.id + '">' + C.icon('play', { size: 20, fill: true }) + (pr && pr.position_seconds > 20 ? 'ادامه از ' + C.dur(pr.position_seconds) : 'پخش') + '</button>' +
      '<button class="btn glass big" data-list="' + m.id + '">' + C.icon(d.list.has(m.id) ? 'check' : 'plus', { size: 20 }) + 'لیست من</button>' +
      '<button class="btn glass big" id="mvLike" aria-pressed="' + liked + '">' + C.icon('heart', { size: 20, fill: liked }) + '<span>' + C.compact(likes) + '</span></button>' +
      '<button class="btn glass icon" id="mvShare" aria-label="اشتراک‌گذاری">' + C.icon('share', { size: 20 }) + '</button>' +
      (C.isPublisher() ? '<a class="btn glass icon" href="#/studio?edit=' + m.id + '" aria-label="ویرایش">' + C.icon('edit', { size: 20 }) + '</a>' : '') + '</div>' +
      (m.description ? '<p class="mv-desc">' + esc(m.description) + '</p>' : '') +
      ((m.genres || []).length ? '<div class="chips">' + m.genres.map(function (g) { return '<a class="chip" href="#/genre/' + encodeURIComponent(g) + '">' + esc(g) + '</a>'; }).join('') + '</div>' : '') +
      '<div class="mv-stats"><span>' + C.icon('eye', { size: 16 }) + C.compact(m.views) + ' بازدید</span></div></div></div></section>' +
      ((m.content_type==='series') ? '<section class="mv-sec" id="episodes"><h2>فصل‌ها و قسمت‌ها</h2><div class="sk sk-rows"></div></section>' : '') +
      '<section class="mv-sec"><h2>نظرها</h2><div id="mvc"></div></section>' + (sim.length ? '<div class="rows">' + row('مشابه', sim) + '</div>' : '');
    wire(el);
    if(m.content_type==='series'){
      var er=await sb.from('seasons').select('*').eq('series_id',m.id).order('season_number');
      var seasons=er.data||[]; var epHtml='';
      for(var si=0;si<seasons.length;si++){
        var eps=(await sb.from('episodes').select('*').eq('season_id',seasons[si].id).order('episode_number')).data||[];
        epHtml+='<div class="season"><h3>فصل '+C.fa(seasons[si].season_number)+(seasons[si].title?' · '+esc(seasons[si].title):'')+'</h3><div class="episode-list">'+eps.map(function(e){return '<button class="episode" data-ep="'+e.id+'"><b>'+C.fa(e.episode_number)+'</b><span><strong>'+esc(e.title)+'</strong><small>'+esc(e.description||'')+'</small></span><i>'+C.icon('play',{size:17})+'</i></button>';}).join('')+'</div></div>';
      }
      $('#episodes',el).innerHTML=epHtml||'<p class="muted">هنوز قسمتی اضافه نشده است.</p>';
      $('#episodes',el).addEventListener('click',async function(e){var b=e.target.closest('[data-ep]');if(!b)return;var id=b.getAttribute('data-ep');var rr=await sb.from('episodes').select('*').eq('id',id).single();if(rr.data){await C.load('player');A.mod.player.open({id:rr.data.id,title:m.title+' — '+rr.data.title,video_url:rr.data.video_url,video_kind:rr.data.video_kind,duration_minutes:rr.data.duration_minutes,poster_url:rr.data.poster_url},{episode:rr.data});}});
    }
    $('#mvShare', el).addEventListener('click', function () { C.share('#/movie/' + m.id, m.title); });
    var lb = $('#mvLike', el);
    lb.addEventListener('click', async function () {
      var on = d.likes.has(m.id); on ? d.likes.delete(m.id) : d.likes.add(m.id); likes += on ? -1 : 1; m.likes_count = likes;
      lb.setAttribute('aria-pressed', !on); lb.innerHTML = C.icon('heart', { size: 20, fill: !on }) + '<span>' + C.compact(likes) + '</span>';
      var rr = await C.withTimeout(sb.rpc('toggle_movie_like',{p_movie:m.id}),9000,'لایک');var r={error:rr.error||((rr.data&&rr.data.ok===false)?new Error(rr.data.code||'like_failed'):null)};
      if (r.error) { C.toast(C.err(r.error), 'bad'); B.invalidate(); }
    });
    await C.load('comments');
    A.comments.mount($('#mvc', el), { table: 'movie_comments', fk: 'movie_id', id: m.id, likes: false, reportType: 'movie_comment' });
  }

  /* ---------- search ---------- */
  async function search(ctx) {
    var el = ctx.el, q = (ctx.query.get('q') || '').trim(), si = $('#sInput'); if (si && si.value !== q) si.value = q;
    if (q.length < 2) {
      var hist = await sb.from('search_history').select('query,created_at').eq('user_id',C.uid).order('created_at',{ascending:false}).limit(8);
      var pop = await sb.from('search_history').select('query').limit(200);
      var counts={}; (pop.data||[]).forEach(function(x){var k=String(x.query||'').trim().toLowerCase();if(k)counts[k]=(counts[k]||0)+1;});
      var popular=Object.keys(counts).sort(function(a,b){return counts[b]-counts[a];}).slice(0,8);
      el.innerHTML='<div class="page-pad"><h1 class="page-h">جستجو</h1><div class="search-home"><p class="muted">فیلم، سریال، دراما یا کاربر را پیدا کن.</p>'+ (hist.data&&hist.data.length?'<h2 class="sec-h">تاریخچه‌ی جستجو</h2><div class="chips scroll-x">'+hist.data.map(function(x){return '<a class="chip" href="#/search?q='+encodeURIComponent(x.query)+'">'+esc(x.query)+'</a>';}).join('')+'</div>':'') +(popular.length?'<h2 class="sec-h">جستجوهای محبوب</h2><div class="chips scroll-x">'+popular.map(function(x){return '<a class="chip" href="#/search?q='+encodeURIComponent(x)+'">'+esc(x)+'</a>';}).join('')+'</div>':'')+'</div></div>'; return;
    }
    await sb.from('search_history').insert({user_id:C.uid,query:q}).then(function(){});
    el.innerHTML = '<div class="page-pad"><h1 class="page-h">نتیجه برای «' + esc(q) + '»</h1><div class="grid-posters">' + C.skel(8, 'sk-poster') + '</div></div>';
    await data();
    var like = '%' + q.replace(/[%_,()\\]/g, ' ') + '%';
    var r = await Promise.all([
      sb.from('movies').select('*').ilike('title', like).limit(40),
      sb.from('profiles').select('id,username,display_name,avatar_url,role,followers_count').or('username.ilike.' + like + ',display_name.ilike.' + like).limit(20)
    ]);
    var ms = (r[0].data || []).filter(function (m) { return m.published || C.isPublisher(); }), us = r[1].data || [];
    ms.forEach(function (m) { D.byId[m.id] = D.byId[m.id] || m; });
    us.forEach(function (u) { C.users[u.id] = u; });
    el.innerHTML = '<div class="page-pad"><h1 class="page-h">نتیجه برای «' + esc(q) + '»</h1>' +
      (us.length ? '<h2 class="sec-h">کاربران</h2><div class="ulist">' + us.map(function (u) {
        return '<a class="uitem" href="#/u/' + esc(u.username) + '">' + C.avatar(u, 46) + '<span><b>' + esc(C.name(u)) + C.badge(u) + '</b><small>@' + esc(u.username) + ' · ' + C.compact(u.followers_count) + ' دنبال‌کننده</small></span></a>';
      }).join('') + '</div>' : '') +
      (ms.length ? '<h2 class="sec-h">فیلم‌ها</h2>' + grid(ms) : '') +
      (!us.length && !ms.length ? C.empty('search', 'چیزی پیدا نشد', 'عبارت دیگری را امتحان کنید.') : '') + '</div>';
    wire(el);
  }
})();
