/* Auxy authentication client: username/password via the same-origin Cloudflare worker. */
(function(){
  'use strict';
  var SUPABASE_URL='https://realtoiyrtvjfohovoda.supabase.co';
  var SUPABASE_KEY='sb_publishable_Y44ggVO5LY98YbNIGp2L-Q_HIUm7GCS';
  var LOGIN_PATH='/login/';
  var HOME_PATH='/home/';
  var A=window.AUXY={LOGIN_PATH:LOGIN_PATH,HOME_PATH:HOME_PATH,SUPABASE_URL:SUPABASE_URL,SUPABASE_KEY:SUPABASE_KEY,VERSION:'30-final',client:null,mod:{}};
  if(!window.supabase||!window.supabase.createClient)return;
  function resilientFetch(input,init){
    init=init||{};var h=new Headers((input&&typeof input!=='string'&&input.headers)||init.headers||{});
    if(!h.has('apikey'))h.set('apikey',SUPABASE_KEY);
    var url=typeof input==='string'?input:(input&&input.url);
    if(url&&url.indexOf(SUPABASE_URL)===0&&url.indexOf('apikey=')<0)url+=(url.indexOf('?')<0?'?':'&')+'apikey='+encodeURIComponent(SUPABASE_KEY);
    return window.fetch(url||input,{method:init.method,body:init.body,mode:init.mode,credentials:init.credentials||'same-origin',cache:init.cache,redirect:init.redirect,referrer:init.referrer,signal:init.signal,headers:h});
  }
  A.client=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{auth:{flowType:'pkce',persistSession:true,autoRefreshToken:true,detectSessionInUrl:true},global:{fetch:resilientFetch}});
  A.api=async function(path,body,token){var h={'content-type':'application/json','x-auxy-client':'web'};if(token)h.Authorization='Bearer '+token;var ctrl=new AbortController(),tm=setTimeout(function(){ctrl.abort();},15000);try{var r=await fetch('/api/'+path,{method:'POST',headers:h,body:JSON.stringify(body||{}),signal:ctrl.signal,credentials:'same-origin',cache:'no-store'});var d=await r.json().catch(function(){return{}});if(!r.ok||d.ok===false)throw Object.assign(new Error(d.message||'درخواست انجام نشد.'),{code:d.code,status:r.status,data:d});return d;}finally{clearTimeout(tm)}};
  A.getConfig=function(){return fetch('/api/config',{cache:'no-store',credentials:'same-origin'}).then(function(r){if(!r.ok)throw new Error('config');return r.json();});};
  A.getSession=function(){return A.client.auth.getSession().then(function(r){return r.data&&r.data.session||null;}).catch(function(){return null;});};
  A.signInWithUsername=async function(username,password,captcha){return A.api('auth/login',{username:username,password:password,captcha:captcha});};
  A.register=async function(username,password,display_name,recovery_email,captcha){return A.api('auth/register',{username,password,display_name,recovery_email,captcha});};
  A.requestRecovery=async function(username,email,captcha){return A.api('auth/recovery',{username,email,captcha});};
  A.setRecoveryEmail=async function(email,captcha){var s=await A.getSession();if(!s)throw new Error('نشست ورود پیدا نشد.');return A.api('auth/set-recovery',{email,captcha},s.access_token);};
  A.signOut=function(){return A.client.auth.signOut({scope:'local'}).catch(function(){}).then(function(){location.replace(LOGIN_PATH);});};
  A.signOutEverywhere=function(){return A.client.auth.signOut({scope:'global'}).catch(function(){}).then(function(){location.replace(LOGIN_PATH);});};
  A.guard=function(){return A.getSession().then(function(s){if(!s){location.replace(LOGIN_PATH);return null;}A.client.auth.onAuthStateChange(function(e){if(e==='SIGNED_OUT')location.replace(LOGIN_PATH);});return s;});};
})();
