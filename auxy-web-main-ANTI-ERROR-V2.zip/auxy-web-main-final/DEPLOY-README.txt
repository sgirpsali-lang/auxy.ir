AUXY WEB MAIN FINAL
Cloudflare Pages root: deploy this folder as-is.
Required secrets for _worker.js: SUPABASE_URL, SUPABASE_ANON_KEY or SUPABASE_PUBLISHABLE_KEY, SUPABASE_SERVICE_ROLE_KEY, RECAPTCHA_SITE_KEY, RECAPTCHA_SECRET. Optional: RECAPTCHA_MIN_SCORE, AUXY_VAST_TAG_URL.
No demo movies are seeded; Studio starts empty.
Run Auxy-Web-Main.sql before public use.
